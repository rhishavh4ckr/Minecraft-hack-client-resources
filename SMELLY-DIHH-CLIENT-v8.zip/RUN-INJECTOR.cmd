@echo off
REM Launch SMELLY DIHH CLIENT injector
setlocal
title SMELLY DIHH CLIENT INJECTOR
echo.
echo  ==============================================
echo   SMELLY DIHH CLIENT - Launching injector...
echo  ==============================================
echo.
if exist build\client-patched.jar (
    start "" javaw -jar build\client-patched.jar
    echo  Launched build\client-patched.jar
) else if exist client-patched.jar (
    start "" javaw -jar client-patched.jar
    echo  Launched client-patched.jar
) else (
    echo  *** client-patched.jar not found!
    echo  First run BUILD.cmd to build it, then run this again.
    echo.
    pause
    exit /b 1
)
echo.
echo  If you don't see the injector window in a few seconds,
echo  re-run this from CMD with: java -jar build\client-patched.jar
echo  so you can see error messages.
echo.
timeout /t 3 >nul
endlocal
