@echo off
REM ============================================================
REM  SMELLY DIHH CLIENT - one-click BUILD script
REM  Place this next to SMELLY-DIHH-CLIENT.jar and double-click.
REM ============================================================
setlocal
title SMELLY DIHH CLIENT - BUILD
echo.
echo  ==========================================
echo   SMELLY DIHH CLIENT - Building...
echo  ==========================================
echo.
if exist build rmdir /s /q build
mkdir build\src
echo [1/6] Extracting...
tar xf SMELLY-DIHH-CLIENT.jar -C build\src
if errorlevel 1 (
    echo *** Failed to extract SMELLY-DIHH-CLIENT.jar
    pause & exit /b 1
)
cd /d build\src
echo [2/6] Scanning sources...
dir /s /b *.java > s.txt
echo [3/6] Compiling with javac...
javac -encoding UTF-8 -source 8 -target 8 -d . @s.txt
if errorlevel 1 (
    echo.
    echo  *** COMPILE FAILED - see errors above ***
    echo.
    cd ..\..
    pause
    exit /b 1
)
del s.txt
echo [4/6] Cleaning sources from output...
del /s /q *.java >nul 2>&1
echo [5/6] Packaging jar...
set JAREXE=
if exist "%ProgramFiles%\Java\jdk-21.0.10\bin\jar.exe" set JAREXE=%ProgramFiles%\Java\jdk-21.0.10\bin\jar.exe
if "%JAREXE%"=="" if exist "%ProgramFiles%\Java\jdk-21\bin\jar.exe" set JAREXE=%ProgramFiles%\Java\jdk-21\bin\jar.exe
if not "%JAREXE%"=="" (
    "%JAREXE%" cfm client-patched.jar META-INF\MANIFEST.MF .
    set USEPS=0
) else (
    echo jar.exe not found; using PowerShell to zip...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '*' -DestinationPath '..\cp.zip' -Force"
    set USEPS=1
)
cd ..\..
if not exist build mkdir build
if "%USEPS%"=="1" (
    move /y build\cp.zip build\client-patched.jar >nul
) else (
    move /y build\src\client-patched.jar build\client-patched.jar >nul
)
if not exist build\client-patched.jar (
    echo.
    echo  *** Packaging failed - no jar produced ***
    pause & exit /b 1
)
echo [6/6] Done.
echo.
echo  ==========================================
echo   BUILD OK!
echo   Jar: %CD%\build\client-patched.jar
echo  ==========================================
echo.
echo  This is an EXTERNAL INJECTOR (not a mod).
echo  Launch Minecraft first, then run:
echo      RUN-INJECTOR.cmd
echo  (or double-click build\client-patched.jar)
echo.
echo  After injecting, press RIGHT_SHIFT in-game.
echo.
pause
endlocal
