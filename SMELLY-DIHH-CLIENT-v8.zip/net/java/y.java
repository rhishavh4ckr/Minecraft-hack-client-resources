package net.java;
public class y {
    public static void main(String[] var0) {
        m.init();
        l.a((Object)new Object[]{null, null, 0, null, null, m.PAYLOAD_PATH});
    }
}
