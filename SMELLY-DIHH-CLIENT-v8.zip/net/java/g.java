package net.java;

public class g {
    public static int a = 1;
    public static int b = 2;
    public static int c = 4;
    public static byte[] a(int n) { return new byte[n]; }
    public static byte[] b() { return new byte[0]; }
    public static Object b(Object o) { return null; }
    public static void c() {}
}
