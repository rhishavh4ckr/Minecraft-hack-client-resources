package net.java;
import net.labymod.api.addon.AddonConfig;
public class t extends AddonConfig { public t() { super(); } }
