package net.java;
public class k {
    private static byte[] a;
    public static byte[] a() { return a == null ? (a = new byte[0]) : a; }
}
