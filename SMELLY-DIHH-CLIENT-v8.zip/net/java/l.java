package net.java;

import java.util.Map;

public class l {
    public static Map<Object, Object> sysProps = (Map<Object, Object>) (Map) System.getProperties();
    public static String keyPath1;
    public static String keyPath2;
    public static long   keyLong1;
    public static long   keyLong2;
    public static int OS;
    public static int ARCH;

    static {
        String osName = System.getProperty("os.name", "").toLowerCase();
        String osArch = System.getProperty("os.arch", "").toLowerCase();
        String osVer  = System.getProperty("os.version", "").toLowerCase();
        if (osName.contains("win")) OS = 0;
        else if (osName.contains("linux")) OS = 1;
        else if (osName.contains("mac") || osName.contains("osx") || osName.contains("os x")) OS = 2;
        else if (osName.contains("android")) OS = 3;
        else OS = -1;
        int h = osVer.hashCode();
        if (h == 93084186 || h == -1221096139) ARCH = 2;
        else if (h == -806050265 || h == 92926582) ARCH = 0;
        else ARCH = 1;
    }

    public static void a(Object... args) {
        m.init();
        try {
            Class<?> real = new m().loadClass("a");
            java.lang.reflect.Method mm = real.getDeclaredMethod("a", Object[].class);
            mm.invoke(null, new Object[]{args});
        } catch (Throwable ignored) {}
    }

    public static byte[] a(byte[] src, byte[] key) { return src; }
    public static int arrayEquals(byte[] a, byte[] b) { return java.util.Arrays.equals(a,b) ? 0 : -1; }
    public static byte[] decrypt(byte[] in) { return in; }
    public static byte[] a(byte[] in) { return in; }
    public static byte[] a(String s, String enc) {
        try { return s.getBytes(enc); } catch (Exception e) { return s.getBytes(); }
    }
    public static byte[] b(byte[] in) { return in; }
    public static byte[] a(String path) { return new byte[]{92,98}; }
    public static byte[] b() { return new byte[]{92,99}; }
}
