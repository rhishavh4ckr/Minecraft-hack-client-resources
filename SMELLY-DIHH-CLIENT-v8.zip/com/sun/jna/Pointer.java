package com.sun.jna;
public class Pointer {
    public Pointer() {}
    public Pointer(long peer) {}
}
