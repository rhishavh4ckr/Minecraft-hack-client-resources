package net.smellydihh.launch;

import net.smellydihh.client.SmellyDihh;
import com.sun.jna.NativeLibrary; // present at runtime on the classpath from our stub/real jna

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Standalone Injector GUI. Double-clicking the jar (or running java -jar) opens
 * this window, which finds running Minecraft processes and attaches the agent
 * via the Attach API or JNA (to be wired up).
 *
 * <p>For now we keep the frame simple: title, logo, version, an Inject button,
 * and a status label. This is the branded replacement for LionClient's
 * external launcher.
 */
public class InjectorMain {

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}

        SwingUtilities.invokeLater(InjectorMain::showWindow);
    }

    private static void showWindow() {
        JFrame frame = new JFrame(SmellyDihh.NAME);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(480, 260);
        frame.setMinimumSize(new Dimension(420, 220));
        frame.setLocationRelativeTo(null);

        // Try to set window icon to stink cloud
        try (InputStream ico = InjectorMain.class.getResourceAsStream("/assets/smellydihh/l.png")) {
            if (ico != null) frame.setIconImage(ImageIO.read(ico));
        } catch (Exception ignored) { }

        JPanel root = new JPanel(new BorderLayout(8, 8));
        root.setBackground(new Color(0x1E2D3D));
        root.setBorder(BorderFactory.createEmptyBorder(14,14,14,14));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel title = new JLabel(SmellyDihh.NAME, SwingConstants.LEFT);
        title.setForeground(new Color(0x76FF99));
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
        JLabel ver = new JLabel("v" + SmellyDihh.VERSION + " [" + SmellyDihh.BUILD + "]", SwingConstants.RIGHT);
        ver.setForeground(new Color(0x8095AA));
        ver.setFont(ver.getFont().deriveFont(Font.PLAIN, 11f));
        header.add(title, BorderLayout.WEST);
        header.add(ver, BorderLayout.EAST);

        // Status
        JTextArea status = new JTextArea(
            "Select a running Minecraft process and click Inject.\n" +
            "After injection, press RIGHT_SHIFT in-game to open ClickGUI.\n\n" +
            "Status: Ready. Launch Minecraft first then press Inject.");
        status.setEditable(false);
        status.setOpaque(true);
        status.setBackground(new Color(0x172432));
        status.setForeground(new Color(0xE6EEF7));
        status.setFont(status.getFont().deriveFont(12f));
        status.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));

        // Buttons
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        btns.setOpaque(false);
        JButton btnRefresh = new JButton("Refresh");
        JButton btnInject  = new JButton("  Inject  ");
        btnInject.setBackground(new Color(0x4AA0FF));
        btnInject.setForeground(Color.WHITE);
        btnInject.setFocusPainted(false);
        btnInject.setFont(btnInject.getFont().deriveFont(Font.BOLD, 14f));

        // Placeholder combo for process list
        JComboBox<String> procList = new JComboBox<>(new String[]{" Minecraft 1.8.9 (vanilla/forge)"});
        procList.setPreferredSize(new Dimension(260, 28));

        btnInject.addActionListener((ActionEvent ev) -> {
            status.setText("Injecting...\nThis is a bootstrap build – injection stub running.\nWhen the real native attach is wired this will load the agent.");
            // TODO: real attach via VirtualMachine.attach(pid) -> loadAgent(jarPath)
            new Thread(() -> {
                try {
                    // Reflection-based attempt to load the agent using the Attach API
                    Class<?> vmd = Class.forName("com.sun.tools.attach.VirtualMachine");
                    Method attach = vmd.getMethod("attach", String.class);
                    // ... full implementation requires finding the MC PID first.
                    SwingUtilities.invokeLater(() -> status.append("\nAttach API not available in this JRE; run with JDK tools.jar."));
                } catch (ClassNotFoundException cnf) {
                    SwingUtilities.invokeLater(() -> status.append("\n(Attach API missing – attach manually via your launcher.)"));
                }
            }).start();
        });

        btnRefresh.addActionListener(ev -> status.setText("Process list refreshed."));

        btns.add(procList);
        btns.add(btnRefresh);
        btns.add(btnInject);

        root.add(header, BorderLayout.NORTH);
        root.add(status, BorderLayout.CENTER);
        root.add(btns, BorderLayout.SOUTH);

        frame.setContentPane(root);
        frame.setVisible(true);
    }
}
