package org.json;
import java.util.*;
public class JSONObject {
    private final LinkedHashMap<String,Object> map = new LinkedHashMap<>();
    public JSONObject() {}
    public JSONObject(String txt) { /* extremely minimal – no parser here for compile */ }
    public JSONObject put(String k, Object v) { map.put(k,v); return this; }
    public Object opt(String k) { return map.get(k); }
    public String optString(String k, String d) { Object v=map.get(k); return v==null?d:v.toString(); }
    public int optInt(String k, int d) { Object v=map.get(k); return v instanceof Number?((Number)v).intValue():d; }
    public boolean optBoolean(String k, boolean d) { Object v=map.get(k); return v instanceof Boolean?(Boolean)v:d; }
    public JSONArray optJSONArray(String k) { Object v=map.get(k); return v instanceof JSONArray?(JSONArray)v:null; }
    public String getString(String k) { return optString(k,""); }
    public int getInt(String k) { return optInt(k,0); }
    public boolean getBoolean(String k) { return optBoolean(k,false); }
    public JSONArray getJSONArray(String k) { JSONArray a=optJSONArray(k); return a==null?new JSONArray():a; }
    public String toString(int indent) { StringBuilder sb=new StringBuilder("{"); boolean f=true; for(Map.Entry<String,Object> e:map.entrySet()){if(!f)sb.append(",");sb.append("\"").append(e.getKey()).append("\":").append(val(e.getValue()));f=false;}sb.append("}");return sb.toString();}
    private static String val(Object o){if(o==null)return"null";if(o instanceof String)return"\""+((String)o).replace("\"","\\\"")+"\"";if(o instanceof Number||o instanceof Boolean)return o.toString();if(o instanceof JSONArray)return o.toString();return"\""+o+"\"";}
}
