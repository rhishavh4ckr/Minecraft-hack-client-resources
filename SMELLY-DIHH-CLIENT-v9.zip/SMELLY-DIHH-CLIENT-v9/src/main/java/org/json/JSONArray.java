package org.json;
import java.util.*;
public class JSONArray {
    private final ArrayList<Object> list = new ArrayList<>();
    public JSONArray(){}
    public JSONArray put(Object o){list.add(o);return this;}
    public int length(){return list.size();}
    public JSONObject getJSONObject(int i){Object v=list.get(i);return v instanceof JSONObject?(JSONObject)v:new JSONObject();}
    public String toString(){StringBuilder sb=new StringBuilder("[");for(int i=0;i<list.size();i++){if(i>0)sb.append(",");Object v=list.get(i);if(v instanceof String)sb.append("\"").append(v).append("\"");else sb.append(v);}sb.append("]");return sb.toString();}
}
