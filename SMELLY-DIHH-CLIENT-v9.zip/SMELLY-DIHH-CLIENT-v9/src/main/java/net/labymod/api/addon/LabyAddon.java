package net.labymod.api.addon;
public abstract class LabyAddon<C> { protected abstract void enable(); protected abstract Class<C> configurationClass(); }
