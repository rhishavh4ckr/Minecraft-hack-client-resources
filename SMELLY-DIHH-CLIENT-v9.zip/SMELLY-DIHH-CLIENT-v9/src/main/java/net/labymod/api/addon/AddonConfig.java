package net.labymod.api.addon;
public class AddonConfig { public AddonConfig(){} }
