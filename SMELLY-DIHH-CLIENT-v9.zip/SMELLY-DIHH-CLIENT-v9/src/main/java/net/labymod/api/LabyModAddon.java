package net.labymod.api;
import java.util.List;
public abstract class LabyModAddon { public abstract void onEnable(); public void loadConfig(){} protected abstract void fillSettings(List list); }
