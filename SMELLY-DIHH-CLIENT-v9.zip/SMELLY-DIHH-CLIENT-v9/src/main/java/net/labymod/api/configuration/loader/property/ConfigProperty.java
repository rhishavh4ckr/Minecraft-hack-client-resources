package net.labymod.api.configuration.loader.property;
public class ConfigProperty {}
