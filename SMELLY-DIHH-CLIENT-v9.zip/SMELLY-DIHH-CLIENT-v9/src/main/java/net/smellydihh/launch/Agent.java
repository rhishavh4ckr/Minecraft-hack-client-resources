package net.smellydihh.launch;

import net.smellydihh.client.core.Bootstrap;
import net.smellydihh.client.core.ClientContext;
import java.lang.instrument.Instrumentation;

public class Agent {
    public static void premain(String arg, Instrumentation inst) {
        Bootstrap.start(ClientContext.TYPE_AGENT);
    }
    public static void agentmain(String arg, Instrumentation inst) {
        Bootstrap.start(ClientContext.TYPE_AGENT);
    }
}
