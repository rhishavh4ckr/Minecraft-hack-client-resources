package net.smellydihh.launch;

import cpw.mods.fml.common.Mod;
import net.smellydihh.client.core.Bootstrap;
import net.smellydihh.client.core.ClientContext;

@Mod(modid = "smellydihh", name = "SMELLY DIHH CLIENT", version = "1.0")
public class ForgeMod {
    public ForgeMod() { Bootstrap.start(ClientContext.TYPE_FORGE); }
}
