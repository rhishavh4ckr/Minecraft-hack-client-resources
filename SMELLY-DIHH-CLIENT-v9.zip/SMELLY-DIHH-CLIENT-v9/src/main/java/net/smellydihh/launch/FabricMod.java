package net.smellydihh.launch;

import net.fabricmc.api.ModInitializer;
import net.smellydihh.client.core.Bootstrap;
import net.smellydihh.client.core.ClientContext;

public class FabricMod implements ModInitializer {
    public void onInitialize() { Bootstrap.start(ClientContext.TYPE_FABRIC); }
}
