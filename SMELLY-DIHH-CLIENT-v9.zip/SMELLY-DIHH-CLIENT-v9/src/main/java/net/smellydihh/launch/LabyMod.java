package net.smellydihh.launch;

import net.labymod.api.addon.LabyAddon;
import net.smellydihh.client.core.Bootstrap;
import net.smellydihh.client.core.ClientContext;
import net.labymod.api.models.addon.annotation.AddonMain;

@AddonMain
public class LabyMod extends LabyAddon<Object> {
    protected void enable() { Bootstrap.start(ClientContext.TYPE_LABY); }
    protected Class<Object> configurationClass() { return Object.class; }
}
