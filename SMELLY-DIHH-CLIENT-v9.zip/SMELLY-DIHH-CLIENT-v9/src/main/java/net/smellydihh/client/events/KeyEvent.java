package net.smellydihh.client.events;

/**
 * Fired on every keyboard event in-game. Key codes use LWJGL GLFW-style IDs.
 */
public class KeyEvent extends Event implements Event.Cancellable {
    private final int key;
    private final int scanCode;
    private final int action;
    private final int modifiers;

    public KeyEvent(int key, int scanCode, int action, int modifiers) {
        this.key = key; this.scanCode = scanCode; this.action = action; this.modifiers = modifiers;
    }
    public int getKey()       { return key; }
    public int getScanCode()  { return scanCode; }
    public int getAction()    { return action; }
    public int getModifiers() { return modifiers; }
    public boolean isPress()  { return action == 1; }
    public boolean isRepeat() { return action == 2; }
}
