package net.smellydihh.client.modules.render;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.BooleanSetting;
import net.smellydihh.client.settings.ColorSetting;
import net.smellydihh.client.settings.ModeSetting;
import net.smellydihh.client.render.Color;

public class ESP extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "ESP rendering mode.", 0, "Box", "2D", "Outline");
    private final ColorSetting color = new ColorSetting("Color", "ESP color.", new Color(255,85,85,180));
    private final BooleanSetting players = new BooleanSetting("Players", "Draw ESP on players.", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", "Draw ESP on mobs.", false);
    public ESP() { super("ESP", "See entities through walls.", Category.RENDER, 0); addSetting(mode); addSetting(color); addSetting(players); addSetting(mobs); }
}
