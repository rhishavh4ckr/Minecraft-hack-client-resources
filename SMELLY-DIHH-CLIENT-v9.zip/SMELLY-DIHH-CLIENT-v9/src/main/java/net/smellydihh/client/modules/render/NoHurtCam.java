package net.smellydihh.client.modules.render;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class NoHurtCam extends Module {
    public NoHurtCam() { super("NoHurtCam", "Disables damage screen shake.", Category.RENDER, 0); }
}
