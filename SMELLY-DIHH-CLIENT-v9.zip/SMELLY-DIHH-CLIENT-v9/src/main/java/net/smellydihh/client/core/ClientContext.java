package net.smellydihh.client.core;

public final class ClientContext {
    public static final int TYPE_AGENT  = 1;
    public static final int TYPE_FORGE  = 5;
    public static final int TYPE_FABRIC = 6;
    public static final int TYPE_LABY   = 5;
}
