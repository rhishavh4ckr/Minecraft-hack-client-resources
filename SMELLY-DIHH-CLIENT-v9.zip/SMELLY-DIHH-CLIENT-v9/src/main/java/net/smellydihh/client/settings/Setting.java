package net.smellydihh.client.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Base class for all module settings. Every setting has a display name, a
 * value, an optional visibility gate, and a change callback list.
 */
public abstract class Setting<T> {

    private final String name;
    private final String description;
    private T value;
    private final T defaultValue;
    private Supplier<Boolean> visibility;
    private final List<Consumer<T>> changeListeners = new ArrayList<>();

    protected Setting(String name, String description, T defaultValue) {
        this.name = name;
        this.description = description;
        this.value = defaultValue;
        this.defaultValue = defaultValue;
        this.visibility = () -> true;
    }

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public T getDefault()          { return defaultValue; }
    public T getValue()            { return value; }

    public void setValue(T value) {
        T validated = clamp(value);
        if (!equal(this.value, validated)) {
            T old = this.value;
            this.value = validated;
            for (Consumer<T> l : changeListeners) {
                try { l.accept(validated); } catch (Throwable ignored) { }
            }
            onChanged(old, validated);
        }
    }

    /** Hook for subclasses that need to react to changes (e.g. bounds clamping). */
    protected void onChanged(T old, T now) { }

    protected T clamp(T v) { return v; }

    public Setting<T> withVisibility(Supplier<Boolean> v) { this.visibility = v; return this; }
    public boolean isVisible() { return visibility.get(); }

    public Setting<T> onChange(Consumer<T> listener) { changeListeners.add(listener); return this; }

    public void reset() { setValue(defaultValue); }

    private static boolean equal(Object a, Object b) { return a == null ? b == null : a.equals(b); }
}
