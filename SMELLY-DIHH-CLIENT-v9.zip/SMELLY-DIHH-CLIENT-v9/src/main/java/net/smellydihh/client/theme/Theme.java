package net.smellydihh.client.theme;

import net.smellydihh.client.render.Color;

/**
 * Theme definition. A theme binds every UI colour (ClickGUI panels, accent,
 * HUD arraylist, watermark, confetti, etc.) so we can swap palettes at
 * runtime. Default theme implements the LionClient/VAPE hybrid requested.
 */
public final class Theme {

    public final String name;

    // ClickGUI panel colours
    public final Color panelBg;           // dark navy panel background
    public final Color panelBgAlt;        // secondary panel shade for headers
    public final Color panelBorder;
    public final Color accent;            // bright blue (#4AA0FF)
    public final Color accentHover;
    public final Color textPrimary;
    public final Color textSecondary;
    public final Color textDisabled;
    public final Color moduleEnabled;     // text for enabled modules
    public final Color categoryBar;       // top tab bar
    public final Color categoryActive;
    public final Color scrollHandle;
    public final Color tooltipBg;
    public final Color tooltipBorder;

    // HUD colours
    public final Color hudBg;             // ArrayList background (dark near-black)
    public final Color hudRailTop;        // top of VAPE-style vertical rail
    public final Color hudRailBottom;     // bottom of VAPE-style vertical rail
    public final Color hudText;
    public final Color hudTextShadow;
    public final Color watermark;

    // Confetti colours used in ClickGUI background
    public final Color[] confetti;

    private Theme(Builder b) {
        this.name = b.name;
        this.panelBg = b.panelBg;
        this.panelBgAlt = b.panelBgAlt;
        this.panelBorder = b.panelBorder;
        this.accent = b.accent;
        this.accentHover = b.accentHover;
        this.textPrimary = b.textPrimary;
        this.textSecondary = b.textSecondary;
        this.textDisabled = b.textDisabled;
        this.moduleEnabled = b.moduleEnabled;
        this.categoryBar = b.categoryBar;
        this.categoryActive = b.categoryActive;
        this.scrollHandle = b.scrollHandle;
        this.tooltipBg = b.tooltipBg;
        this.tooltipBorder = b.tooltipBorder;
        this.hudBg = b.hudBg;
        this.hudRailTop = b.hudRailTop;
        this.hudRailBottom = b.hudRailBottom;
        this.hudText = b.hudText;
        this.hudTextShadow = b.hudTextShadow;
        this.watermark = b.watermark;
        this.confetti = b.confetti;
    }

    /** LionClient-style navy + VAPE v4 orange/red rail default. */
    public static Theme smellyDihhDefault() {
        return new Builder("Smelly Dihh Dark")
                .panelBg        (new Color(0x1E2D3D))
                .panelBgAlt     (new Color(0x182533))
                .panelBorder    (new Color(0x0F1924))
                .accent         (new Color(0x4AA0FF))
                .accentHover    (new Color(0x6EB4FF))
                .textPrimary    (new Color(0xE6EEF7))
                .textSecondary  (new Color(0x8095AA))
                .textDisabled   (new Color(0x4B5F73))
                .moduleEnabled  (new Color(0x4AA0FF))
                .categoryBar    (new Color(0x172432))
                .categoryActive (new Color(0x4AA0FF))
                .scrollHandle   (new Color(0x4AA0FF))
                .tooltipBg      (new Color(0x101B26, 230))
                .tooltipBorder  (new Color(0x4AA0FF))
                .hudBg          (new Color(0x020203, 150))
                .hudRailTop     (new Color(0xFFAA00))     // orange
                .hudRailBottom  (new Color(0xE63939))     // red
                .hudText        (new Color(0xFFFFFF))
                .hudTextShadow  (new Color(0x000000, 210))
                .watermark      (new Color(0x76FF99))     // cartoon green graffiti vibe
                .confetti       (new Color[]{
                    new Color(0x4AA0FF), new Color(0xFF5555),
                    new Color(0xFFAA00), new Color(0x76FF99),
                    new Color(0xFFFFFF), new Color(0xAA55FF),
                })
                .build();
    }

    public static final class Builder {
        String name; Color panelBg, panelBgAlt, panelBorder, accent, accentHover;
        Color textPrimary, textSecondary, textDisabled, moduleEnabled;
        Color categoryBar, categoryActive, scrollHandle, tooltipBg, tooltipBorder;
        Color hudBg, hudRailTop, hudRailBottom, hudText, hudTextShadow, watermark;
        Color[] confetti;
        Builder(String n){ this.name = n; }
        Builder panelBg        (Color v){ panelBg=v; return this; }
        Builder panelBgAlt     (Color v){ panelBgAlt=v; return this; }
        Builder panelBorder    (Color v){ panelBorder=v; return this; }
        Builder accent         (Color v){ accent=v; return this; }
        Builder accentHover    (Color v){ accentHover=v; return this; }
        Builder textPrimary    (Color v){ textPrimary=v; return this; }
        Builder textSecondary  (Color v){ textSecondary=v; return this; }
        Builder textDisabled   (Color v){ textDisabled=v; return this; }
        Builder moduleEnabled  (Color v){ moduleEnabled=v; return this; }
        Builder categoryBar    (Color v){ categoryBar=v; return this; }
        Builder categoryActive (Color v){ categoryActive=v; return this; }
        Builder scrollHandle   (Color v){ scrollHandle=v; return this; }
        Builder tooltipBg      (Color v){ tooltipBg=v; return this; }
        Builder tooltipBorder  (Color v){ tooltipBorder=v; return this; }
        Builder hudBg          (Color v){ hudBg=v; return this; }
        Builder hudRailTop     (Color v){ hudRailTop=v; return this; }
        Builder hudRailBottom  (Color v){ hudRailBottom=v; return this; }
        Builder hudText        (Color v){ hudText=v; return this; }
        Builder hudTextShadow  (Color v){ hudTextShadow=v; return this; }
        Builder watermark      (Color v){ watermark=v; return this; }
        Builder confetti       (Color[] v){ confetti=v; return this; }
        Theme build(){ return new Theme(this); }
    }
}
