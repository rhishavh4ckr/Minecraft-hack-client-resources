package net.smellydihh.client.settings;

import net.smellydihh.client.render.Color;

/** Setting backed by an ARGB integer color with optional rainbow support. */
public class ColorSetting extends Setting<Color> {
    private boolean rainbow;
    private float rainbowSpeed;
    public ColorSetting(String name, String description, Color defaultColor) {
        super(name, description, defaultColor);
        this.rainbow = false;
        this.rainbowSpeed = 1.0f;
    }
    public ColorSetting(String name, String description, int argb) {
        this(name, description, new Color(argb));
    }
    public boolean isRainbow() { return rainbow; }
    public void setRainbow(boolean rainbow) { this.rainbow = rainbow; }
    public float getRainbowSpeed() { return rainbowSpeed; }
    public void setRainbowSpeed(float s) { this.rainbowSpeed = s; }
    /** Returns the current ARGB int (animated if rainbow enabled). */
    public int getCurrentARGB(float partialTicks) {
        if (!rainbow) return getValue().getARGB();
        long time = System.currentTimeMillis();
        float hue = ((time * 0.001f * rainbowSpeed) % 1.0f);
        return java.awt.Color.HSBtoRGB(hue, 1.0f, 1.0f) | (getValue().getAlpha() << 24);
    }
}
