package net.smellydihh.client.modules.render;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.ColorSetting;
import net.smellydihh.client.render.Color;

public class ChestESP extends Module {
    private final ColorSetting chest  = new ColorSetting("Chest", "Chest color.", new Color(255,170,0));
    private final ColorSetting echest = new ColorSetting("Ender Chest", "Ender chest color.", new Color(170,85,255));
    public ChestESP() { super("ChestESP", "Highlight chests through walls.", Category.RENDER, 0); addSetting(chest); addSetting(echest); }
}
