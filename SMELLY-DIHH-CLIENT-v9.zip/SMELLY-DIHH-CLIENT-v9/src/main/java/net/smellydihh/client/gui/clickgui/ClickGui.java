package net.smellydihh.client.gui.clickgui;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.core.ModuleManager;
import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.render.Color;
import net.smellydihh.client.render.Render2D;
import net.smellydihh.client.theme.Theme;
import net.smellydihh.client.theme.ThemeManager;
import net.smellydihh.client.util.reflect.Reflection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * LionClient-style ClickGUI with a top tab bar (COMBAT/MOVEMENT/...),
 * navy panels, bright blue accent, left-side module list, right-side
 * settings pane, and a confetti background.
 *
 * <p>Renders itself when its screen is open (see {@link ClickGuiScreen}).
 */
public class ClickGui {

    public static final int TAB_HEIGHT = 24;
    public static final int PANEL_HEADER = 18;
    public static final int ROW_HEIGHT = 16;
    public static final int PANEL_WIDTH = 280;

    private Category activeCategory = Category.COMBAT;
    private Module expanded = null; // module with settings open on the right
    private final Map<Category, Panel> panels = new HashMap<>();
    private final List<ConfettiParticle> confetti = new ArrayList<>();
    private long openedAt;
    private String search = "";
    private boolean searchFocused;

    public ClickGui() {
        Random r = new Random(1337);
        Theme t = ThemeManager.instance().getActive();
        for (int i = 0; i < 80; i++) {
            Color c = t.confetti[r.nextInt(t.confetti.length)];
            confetti.add(new ConfettiParticle(r, c));
        }
    }

    public void open() { openedAt = System.currentTimeMillis(); expanded = null; }
    public void close() {}
    public Category getActiveCategory() { return activeCategory; }
    public void setActiveCategory(Category c) { this.activeCategory = c; expanded = null; }

    public void setSearch(String s) { this.search = s == null ? "" : s; }
    public String getSearch() { return search; }
    public boolean isSearchFocused() { return searchFocused; }
    public void setSearchFocused(boolean f) { this.searchFocused = f; }

    public Module getExpanded() { return expanded; }
    public void setExpanded(Module m) { this.expanded = (expanded == m) ? null : m; }

    public void render(int mouseX, int mouseY, float pt) {
        Theme t = ThemeManager.instance().getActive();

        // Background confetti
        renderConfetti(t);

        // Tab bar at top
        renderTabBar(t, mouseX, mouseY);

        // Main panel for active category
        int panelY = TAB_HEIGHT + 4;
        int panelX = 6;
        int panelH = 400;

        // Left panel (module list)
        Render2D.fillRect(panelX, panelY, PANEL_WIDTH, panelH, t.panelBg);
        Render2D.fillRect(panelX, panelY, PANEL_WIDTH, PANEL_HEADER, t.panelBgAlt);
        // Header text (no font renderer fallback, use rects)
        drawHeader(panelX, panelY, activeCategory.getDisplayName() + " (" + ModuleManager.instance().getByCategory(activeCategory).size() + ")", t);

        // Search field
        int sy = panelY + PANEL_HEADER + 2;
        Render2D.fillRect(panelX+4, sy, PANEL_WIDTH-8, 14, t.panelBgAlt);
        drawText(panelX+8, sy+3, search.isEmpty() ? "Search..." : search, search.isEmpty() ? t.textSecondary : t.textPrimary);

        // Module list
        List<Module> modules = filterModules(ModuleManager.instance().getByCategory(activeCategory));
        int rowY = sy + 16;
        for (Module m : modules) {
            boolean hover = mouseX >= panelX+4 && mouseX <= panelX+PANEL_WIDTH-4
                    && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT;
            if (hover) Render2D.fillRect(panelX+4, rowY, PANEL_WIDTH-8, ROW_HEIGHT, t.panelBgAlt);
            boolean active = m.isEnabled();
            drawText(panelX+10, rowY+4, m.getName(), active ? t.moduleEnabled : t.textPrimary);
            if (expanded == m) Render2D.fillRect(panelX+6, rowY+2, 2, ROW_HEIGHT-4, t.accent);
            rowY += ROW_HEIGHT;
            if (rowY > panelY + panelH - 10) break;
        }

        // Right panel (settings of expanded module)
        if (expanded != null) {
            int rx = panelX + PANEL_WIDTH + 6;
            int rw = 260;
            Render2D.fillRect(rx, panelY, rw, panelH, t.panelBg);
            Render2D.fillRect(rx, panelY, rw, PANEL_HEADER, t.panelBgAlt);
            drawHeader(rx, panelY, expanded.getName(), t);
            drawDescription(rx, panelY + PANEL_HEADER, expanded.getDescription(), t);
        }
    }

    private List<Module> filterModules(List<Module> in) {
        List<Module> out = new ArrayList<>();
        String s = search.toLowerCase();
        for (Module m : in) if (s.isEmpty() || m.getName().toLowerCase().contains(s)) out.add(m);
        return out;
    }

    private void renderConfetti(Theme t) {
        long now = System.currentTimeMillis();
        for (ConfettiParticle p : confetti) {
            double age = ((now - openedAt) % 20000) / 20000.0;
            int x = (int)((p.x0 + p.vx * age * 800) % 900);
            int y = (int)((p.y0 + p.vy * age * 600) % 600);
            if (x < 0) x += 900;
            if (y < 0) y += 600;
            Render2D.drawConfetti(x, y, p.size, p.color);
        }
    }

    private void renderTabBar(Theme t, int mx, int my) {
        Category[] cats = Category.values();
        int tabW = 80;
        int x = 4;
        Render2D.fillRect(0, 0, 1920, TAB_HEIGHT, t.categoryBar);
        for (Category c : cats) {
            boolean hover = mx >= x && mx <= x+tabW && my >= 0 && my <= TAB_HEIGHT;
            boolean selected = c == activeCategory;
            if (selected) {
                Render2D.fillRect(x, 0, tabW, TAB_HEIGHT, t.categoryActive);
            } else if (hover) {
                Render2D.fillRect(x, 0, tabW, TAB_HEIGHT, t.accent.withAlpha(70));
            }
            drawTextCentered(x + tabW/2, 7, c.getDisplayName(),
                    selected ? Color.WHITE : (hover ? Color.WHITE : t.textSecondary));
            x += tabW;
        }
        // window title on right
        drawTextRight(1280-4, 7, SmellyDihh.NAME + " v" + SmellyDihh.VERSION, t.accent);
    }

    public void mouseClicked(int mx, int my, int button) {
        Category[] cats = Category.values();
        int tabW = 80;
        int x = 4;
        for (Category c : cats) {
            if (mx >= x && mx <= x+tabW && my >= 0 && my <= TAB_HEIGHT) {
                setActiveCategory(c);
                return;
            }
            x += tabW;
        }
        // Search field click
        int panelY = TAB_HEIGHT + 4;
        int panelX = 6;
        int sy = panelY + PANEL_HEADER + 2;
        if (mx >= panelX+4 && mx <= panelX+PANEL_WIDTH-4 && my >= sy && my <= sy+14) {
            searchFocused = true;
            return;
        } else searchFocused = false;

        // Module list clicks
        List<Module> modules = filterModules(ModuleManager.instance().getByCategory(activeCategory));
        int rowY = sy + 16;
        for (Module m : modules) {
            if (mx >= panelX+4 && mx <= panelX+PANEL_WIDTH-4 && my >= rowY && my <= rowY + ROW_HEIGHT) {
                if (button == 0) {
                    if (mx > panelX + PANEL_WIDTH - 30) {
                        setExpanded(m); // right side of row = expand arrow
                    } else {
                        m.toggle();
                    }
                } else if (button == 1) {
                    setExpanded(m);
                }
                return;
            }
            rowY += ROW_HEIGHT;
        }
    }

    public void keyTyped(char ch, int key) {
        if (!searchFocused) return;
        if (key == 14) { if (!search.isEmpty()) search = search.substring(0, search.length()-1); return; } // backspace
        if (key == 28) { searchFocused = false; return; } // enter
        if (ch >= 32 && ch < 127) search += ch;
    }

    // ----- minimal text rendering using rects (fallback when no fr) -----
    private void drawText(int x, int y, String text, Color c) {
        if (text == null) return;
        // Use Minecraft font renderer when available
        Object fr = getFontRenderer();
        if (fr != null) {
            try {
                java.lang.reflect.Method dm = fr.getClass().getMethod("drawString", String.class, int.class, int.class, int.class, boolean.class);
                dm.setAccessible(true);
                dm.invoke(fr, text, x, y, c.getARGB(), true);
                return;
            } catch (Throwable ignored) {}
        }
        // Fallback: render a stub bar to represent text (we don't have a pixel font in bare java)
        Render2D.fillRect(x, y+2, text.length()*5, 7, c.withAlpha(200));
    }
    private void drawTextCentered(int cx, int y, String text, Color c) {
        drawText(cx - text.length()*3, y, text, c);
    }
    private void drawTextRight(int rx, int y, String text, Color c) {
        drawText(rx - text.length()*6, y, text, c);
    }
    private void drawHeader(int px, int py, String text, Theme t) {
        drawText(px+6, py+5, text, t.accent);
    }
    private void drawDescription(int px, int py, String desc, Theme t) {
        if (desc == null) return;
        for (int i = 0; i < desc.length(); i += 40) {
            String line = desc.substring(i, Math.min(i+40, desc.length()));
            drawText(px+8, py + 2 + (i/40)*10, line, t.textSecondary);
        }
    }

    private static Object getFontRenderer() {
        Object mc = net.smellydihh.client.util.MinecraftBridge.getMinecraft();
        if (mc == null) return null;
        for (String f : new String[]{"fontRendererObj","fontRenderer","field_71466_p","a"}) {
            try { return Reflection.getMember(mc, f); } catch (Throwable ignored) {}
        }
        return null;
    }

    private static final class ConfettiParticle {
        final float x0,y0,vx,vy; final int size; final Color color;
        ConfettiParticle(Random r, Color c){
            x0 = r.nextFloat(800); y0 = r.nextFloat(600);
            vx = (r.nextFloat()-0.3f)*1.5f; vy = (r.nextFloat()+0.2f)*0.8f;
            size = 2 + r.nextInt(3);
            color = c;
        }
    }
}
