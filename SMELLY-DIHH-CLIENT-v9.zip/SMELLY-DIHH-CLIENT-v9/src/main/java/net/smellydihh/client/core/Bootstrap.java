package net.smellydihh.client.core;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.command.CommandManager;
import net.smellydihh.client.config.ConfigManager;
import net.smellydihh.client.events.ClientStartEvent;
import net.smellydihh.client.events.EventBus;
import net.smellydihh.client.font.FontManager;
import net.smellydihh.client.gui.clickgui.ClickGuiScreen;
import net.smellydihh.client.gui.hud.HudRenderer;
import net.smellydihh.client.theme.ThemeManager;
import net.smellydihh.client.util.MinecraftBridge;

/**
 * Entry point for the SMELLY DIHH CLIENT. Call {@link #start(int)} from any
 * of the bootstrap entry points (agent premain, Forge/Fabric/LabyMod constructors)
 * and pass the bootstrap type (1=agent, 5=Forge, 6=Fabric).
 */
public final class Bootstrap {
    private static boolean started;
    public static synchronized void start(int bootstrapType) {
        if (started) return;
        started = true;
        System.out.println("[" + SmellyDihh.NAME + "] Bootstrapping (type=" + bootstrapType + ", version=" + SmellyDihh.VERSION + ")");

        MinecraftBridge.init();
        FontManager.instance();                    // loads fonts
        ThemeManager.instance();                   // registers default theme
        CommandManager.instance().registerDefaults();
        ConfigManager.instance().init();
        ModuleManager.instance().registerAll();
        HudRenderer.instance().register();
        ClickGuiScreen.instance();                 // wires the RIGHT_SHIFT key
        // After managers are up, load autosave
        ConfigManager.instance().autoLoad();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> ConfigManager.instance().autoSave(), "SmellyDihh-Shutdown"));
        EventBus.get().post(new ClientStartEvent());
        NotificationManager.instance().post("Welcome", SmellyDihh.NAME + " loaded. Press RIGHT_SHIFT.");
        System.out.println("[" + SmellyDihh.NAME + "] Ready.");
    }
    public static boolean isStarted() { return started; }
}
