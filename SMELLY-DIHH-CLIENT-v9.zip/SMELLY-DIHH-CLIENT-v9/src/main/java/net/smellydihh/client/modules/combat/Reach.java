package net.smellydihh.client.modules.combat;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.NumberSetting;

public class Reach extends Module {
    private final NumberSetting dist = new NumberSetting("Distance", "Reach distance.", 3.2, 3.0, 6.0, 0.1);
    public Reach() { super("Reach", "Extend your attack range.", Category.COMBAT, 0); addSetting(dist); }
}
