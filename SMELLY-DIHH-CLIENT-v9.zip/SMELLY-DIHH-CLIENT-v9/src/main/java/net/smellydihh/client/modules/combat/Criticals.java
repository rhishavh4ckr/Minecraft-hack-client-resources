package net.smellydihh.client.modules.combat;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class Criticals extends Module {
    public Criticals() { super("Criticals", "Always do critical hits.", Category.COMBAT, 0); }
}
