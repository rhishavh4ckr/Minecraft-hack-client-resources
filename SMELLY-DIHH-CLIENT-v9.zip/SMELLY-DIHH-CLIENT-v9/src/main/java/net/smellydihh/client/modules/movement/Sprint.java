package net.smellydihh.client.modules.movement;

import net.smellydihh.client.events.ClientTickEvent;
import net.smellydihh.client.events.EventBus;
import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.BooleanSetting;
import net.smellydihh.client.util.MinecraftBridge;
import net.smellydihh.client.util.reflect.Reflection;

public class Sprint extends Module {
    private final BooleanSetting allDirs = new BooleanSetting("All Directions", "Sprint even when walking sideways/backwards.", true);
    public Sprint() {
        super("Sprint", "Always sprints when moving.", Category.MOVEMENT, 0);
        addSetting(allDirs);
    }

    @EventBus.Handler
    public void onTick(ClientTickEvent e) {
        if (e.getPhase() != ClientTickEvent.Phase.PRE) return;
        Object player = MinecraftBridge.getPlayer();
        if (player == null) return;
        try { Reflection.invoke(player, "setSprinting", true); } catch (Throwable ignored) { }
    }
}
