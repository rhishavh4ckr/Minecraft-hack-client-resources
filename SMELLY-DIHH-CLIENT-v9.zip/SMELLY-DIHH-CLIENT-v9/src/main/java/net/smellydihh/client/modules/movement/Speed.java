package net.smellydihh.client.modules.movement;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.NumberSetting;

public class Speed extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", "Movement multiplier.", 1.5, 0.1, 5.0, 0.1);
    public Speed() { super("Speed", "Move faster.", Category.MOVEMENT, 0); addSetting(speed); }
}
