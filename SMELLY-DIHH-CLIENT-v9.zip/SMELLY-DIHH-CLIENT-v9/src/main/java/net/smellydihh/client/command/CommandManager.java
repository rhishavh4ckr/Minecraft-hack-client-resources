package net.smellydihh.client.command;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.command.commands.*;
import net.smellydihh.client.core.ModuleManager;
import net.smellydihh.client.modules.Module;

import java.util.*;

public final class CommandManager {
    private static CommandManager instance;
    public static CommandManager instance() { if (instance==null) instance=new CommandManager(); return instance; }

    private final Map<String, Command> commands = new LinkedHashMap<>();
    public char prefix = '.';

    public void registerDefaults() {
        register(new HelpCommand());
        register(new ToggleCommand());
        register(new BindCommand());
        register(new ConfigCommand());
        register(new ThemeCommand());
    }
    public void register(Command c) { commands.put(c.name().toLowerCase(Locale.ROOT), c); }
    public Collection<Command> getCommands() { return commands.values(); }
    public Command get(String n) { return commands.get(n.toLowerCase(Locale.ROOT)); }

    public boolean dispatch(String message) {
        if (message == null || message.isEmpty() || message.charAt(0) != prefix) return false;
        String[] parts = message.substring(1).split(" ");
        if (parts.length == 0) return false;
        Command c = get(parts[0]);
        if (c == null) {
            sendError("Unknown command. Type " + prefix + "help");
            return true;
        }
        String[] args = Arrays.copyOfRange(parts, 1, parts.length);
        c.execute(args);
        return true;
    }

    public static void sendMsg(String s) {
        // Send chat message via reflection
        System.out.println("[" + SmellyDihh.NAME + "] " + s);
    }
    public static void sendError(String s) { System.err.println("[" + SmellyDihh.NAME + "] " + s); }
}
