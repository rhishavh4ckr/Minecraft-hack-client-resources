package net.smellydihh.client.modules.movement;

import net.smellydihh.client.events.ClientTickEvent;
import net.smellydihh.client.events.EventBus;
import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.util.MinecraftBridge;
import net.smellydihh.client.util.reflect.Reflection;

public class NoFall extends Module {
    public NoFall() { super("NoFall", "Prevents fall damage.", Category.MOVEMENT, 0); }

    @EventBus.Handler
    public void onTick(ClientTickEvent e) {
        Object player = MinecraftBridge.getPlayer();
        if (player == null) return;
        Object onGround = Reflection.getMember(player, "onGround");
        Object motionY  = Reflection.getMember(player, "motionY");
        if (onGround instanceof Boolean && motionY instanceof Number && !((Boolean)onGround)) {
            double mY = ((Number)motionY).doubleValue();
            if (mY < 0) {
                Reflection.setMember(player, "onGround", true);
            }
        }
    }
}
