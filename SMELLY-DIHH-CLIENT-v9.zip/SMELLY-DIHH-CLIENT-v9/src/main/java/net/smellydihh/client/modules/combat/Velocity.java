package net.smellydihh.client.modules.combat;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.NumberSetting;

public class Velocity extends Module {
    private final NumberSetting horiz = new NumberSetting("Horizontal", "Horizontal knockback %.", 0, 0, 100, 1);
    private final NumberSetting vert  = new NumberSetting("Vertical", "Vertical knockback %.", 0, 0, 100, 1);
    public Velocity() { super("Velocity", "Reduce knockback.", Category.COMBAT, 0); addSetting(horiz); addSetting(vert); }
}
