package net.smellydihh.client.command;

public interface Command {
    String name();
    String syntax();
    String description();
    void execute(String[] args);
}
