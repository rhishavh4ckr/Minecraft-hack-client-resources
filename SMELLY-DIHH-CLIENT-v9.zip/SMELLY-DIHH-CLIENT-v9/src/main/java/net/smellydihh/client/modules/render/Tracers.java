package net.smellydihh.client.modules.render;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.ColorSetting;
import net.smellydihh.client.render.Color;

public class Tracers extends Module {
    private final ColorSetting color = new ColorSetting("Line Color", "Tracer line color.", new Color(255,85,85,220));
    public Tracers() { super("Tracers", "Lines pointing at entities.", Category.RENDER, 0); addSetting(color); }
}
