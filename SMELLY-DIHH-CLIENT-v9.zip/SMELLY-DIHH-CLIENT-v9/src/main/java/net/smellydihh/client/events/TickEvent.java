package net.smellydihh.client.events;

public class TickEvent extends Event {
    public enum Phase { IN, OUT }
    private final Phase phase;
    public TickEvent(Phase phase) { this.phase = phase; }
    public Phase getPhase() { return phase; }
}
