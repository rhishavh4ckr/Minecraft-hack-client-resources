package net.smellydihh.client.core;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.modules.combat.*;
import net.smellydihh.client.modules.misc.*;
import net.smellydihh.client.modules.movement.*;
import net.smellydihh.client.modules.player.*;
import net.smellydihh.client.modules.render.*;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * Registry of every {@link Module}. Populated on bootstrap.
 */
public final class ModuleManager {

    private final List<Module> modules = new CopyOnWriteArrayList<>();
    private static ModuleManager instance;

    private ModuleManager() { }

    public static ModuleManager instance() {
        if (instance == null) instance = new ModuleManager();
        return instance;
    }

    public void register(Module m) { modules.add(m); }

    public void registerAll() {
        // Combat
        register(new KillAura());
        register(new Criticals());
        register(new Reach());
        register(new Velocity());
        // Movement
        register(new Sprint());
        register(new Speed());
        register(new Fly());
        register(new NoFall());
        register(new Step());
        register(new Jesus());
        // Player
        register(new FastPlace());
        register(new NoRotate());
        register(new AutoArmor());
        register(new Blink());
        // Render
        register(new ESP());
        register(new Tracers());
        register(new Fullbright());
        register(new NoHurtCam());
        register(new Nametags());
        register(new ChestESP());
        // Misc
        register(new ChatSuffix());
        register(new FastChat());
        register(new AutoRespawn());
        register(new Timer());
        register(new ClickGUIModule());
        register(new HudEditorModule());
    }

    public List<Module> getModules()           { return Collections.unmodifiableList(modules); }
    public List<Module> getEnabled()           { return modules.stream().filter(Module::isEnabled).collect(Collectors.toList()); }
    public List<Module> getByCategory(Category c) { return modules.stream().filter(m -> m.getCategory() == c).collect(Collectors.toList()); }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> clazz) {
        for (Module m : modules) if (m.getClass() == clazz) return (T) m;
        return null;
    }

    public Module getByName(String name) {
        String needle = name.replace("_", " ").replace("-", " ").toLowerCase(Locale.ROOT);
        for (Module m : modules) if (m.getName().toLowerCase(Locale.ROOT).equals(needle)) return m;
        for (Module m : modules) if (m.getName().toLowerCase(Locale.ROOT).contains(needle)) return m;
        return null;
    }
}
