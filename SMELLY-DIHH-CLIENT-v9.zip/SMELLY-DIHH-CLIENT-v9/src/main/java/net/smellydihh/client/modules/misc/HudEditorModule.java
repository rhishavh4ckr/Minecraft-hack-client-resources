package net.smellydihh.client.modules.misc;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class HudEditorModule extends Module {
    public HudEditorModule() { super("HudEditor", "Drag HUD elements around.", Category.CLIENT, 0); setHidden(true); }
}
