package net.smellydihh.client.events;

/** Fired once when the client finishes bootstrapping. */
public class ClientStartEvent extends Event { }
