package net.smellydihh.client.render;

import net.smellydihh.client.util.reflect.Reflection;

import java.awt.image.BufferedImage;
import java.lang.reflect.Method;

/**
 * 2D drawing helpers that bind to Minecraft's GuiScreen/GuiGraphics
 * depending on version. All methods gracefully no-op if the GL/classes are
 * not available (e.g. during bootstrap).
 */
public final class Render2D {

    private Render2D() { }

    // -------------------- GL helpers (reflection) --------------------
    private static boolean glInit;
    private static Method glEnable, glDisable, glBlendFunc, glColor;
    private static Method enableAlpha, disableAlpha;

    private static void initGl() {
        if (glInit) return;
        glInit = true;
        try {
            Class<?> gl = Class.forName("org.lwjgl.opengl.GL11");
            glEnable = gl.getMethod("glEnable", int.class);
            glDisable = gl.getMethod("glDisable", int.class);
            glBlendFunc = gl.getMethod("glBlendFunc", int.class, int.class);
            glColor = gl.getMethod("glColor4f", float.class, float.class, float.class, float.class);
        } catch (Throwable ignored) { }
        try {
            Class<?> sb = Class.forName("net.minecraft.client.renderer.GlStateManager");
            enableAlpha = sb.getMethod("enableAlpha");
            disableAlpha = sb.getMethod("disableAlpha");
        } catch (Throwable ignored) { }
    }

    public static void enableBlend() {
        initGl();
        safeInvoke(glEnable, 3042 /* GL_BLEND */);
        safeInvoke(glBlendFunc, 770 /* SRC_ALPHA */, 771 /* ONE_MINUS_SRC_ALPHA */);
        safeInvoke(enableAlpha);
    }
    public static void disableBlend() {
        initGl();
        safeInvoke(glDisable, 3042);
        safeInvoke(disableAlpha);
    }
    public static void color(Color c) {
        initGl();
        safeInvoke(glColor, c.getRedF(), c.getGreenF(), c.getBlueF(), c.getAlphaF());
    }
    private static void safeInvoke(Method m, Object... args) {
        if (m == null) return;
        try { m.invoke(null, args); } catch (Throwable ignored) { }
    }

    // -------------------- Shape helpers via Minecraft GuiDraw --------------------

    /**
     * Draw a filled rectangle in screen space.
     * We search for drawRect on GuiScreen / DrawContextHelper / GuiGraphics.
     */
    public static void fillRect(int x, int y, int w, int h, Color color) {
        try {
            Class<?> gui = Class.forName("net.minecraft.client.gui.Gui");
            // void drawRect(int left, int top, int right, int bottom, int color)
            Method dr;
            try {
                dr = gui.getMethod("drawRect", int.class, int.class, int.class, int.class, int.class);
            } catch (NoSuchMethodException e) {
                dr = gui.getDeclaredMethod("func_73736_a", int.class, int.class, int.class, int.class, int.class);
            }
            dr.setAccessible(true);
            dr.invoke(null, x, y, x + w, y + h, color.getARGB());
            return;
        } catch (Throwable ignored) { }
        // 1.17+ uses GuiGraphics
        try {
            // Called through our DrawContextBridge later – fallback: ignore
        } catch (Throwable ignored) { }
    }

    public static void fillRectGradient(int x, int y, int w, int h, Color top, Color bottom) {
        fillRect(x, y, w, h/2, top);
        fillRect(x, y + h/2, w, h - h/2, bottom);
    }

    /** VAPE-style vertical accent rail (orange → red gradient). */
    public static void drawAccentRail(int x, int y, int h, Color top, Color bottom) {
        int railW = 2;
        for (int i = 0; i < h; i++) {
            float t = (float)i / Math.max(1, h-1);
            fillRect(x, y+i, railW, 1, top.lerp(bottom, t));
        }
    }

    public static void drawRoundedRect(int x, int y, int w, int h, int radius, Color color) {
        fillRect(x+radius, y, w-radius*2, h, color);
        fillRect(x, y+radius, w, h-radius*2, color);
        // corner dots (simple, no full anti-aliasing)
        for (int r = 0; r < radius; r++) {
            int seg = (int)Math.round(Math.sqrt(radius*radius - r*r));
            fillRect(x+radius-seg, y+r, seg*2, 1, color);
            fillRect(x+radius-seg, y+h-1-r, seg*2, 1, color);
        }
    }

    /** Draw the VAPE-style ArrayList module background behind text. */
    public static void drawArrayListBG(int x, int y, int textWidth, int textHeight, Color bg) {
        int margin = 2;
        int railW = 2;
        fillRect(x + railW, y, textWidth + margin*2, textHeight, bg);
    }

    /** Draw a confetti dot (small colored square). */
    public static void drawConfetti(int x, int y, int size, Color c) {
        fillRect(x, y, size, size, c);
    }

    // -------------------- Image helper --------------------
    public static void drawImage(BufferedImage img, int x, int y, int w, int h) {
        // Use Minecraft's texture manager – for now we just render pixel-by-pixel for small previews
        for (int py = 0; py < h; py++) {
            for (int px = 0; px < w; px++) {
                int sx = (int)((float)px / w * img.getWidth());
                int sy = (int)((float)py / h * img.getHeight());
                int argb = img.getRGB(sx, sy);
                int a = (argb >> 24) & 0xFF;
                if (a > 0) fillRect(x+px, y+py, 1, 1, new Color(argb));
            }
        }
    }
}
