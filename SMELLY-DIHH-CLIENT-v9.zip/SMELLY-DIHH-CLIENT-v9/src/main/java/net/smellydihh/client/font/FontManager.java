package net.smellydihh.client.font;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.render.Color;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Loads TTF fonts (Proxima Nova, Assetsio) and provides a drawString method
 * that uses immediate-mode bitmap blits through Minecraft's text renderer when
 * available, otherwise falls back to a pure-Java pixel renderer.
 *
 * <p>Note: the in-game HUD prefers Minecraft's native {@code FontRenderer} for
 * integration with chat and signs, but the ClickGUI and watermark use the TTF
 * fonts to match the VAPE/Lion aesthetic.
 */
public final class FontManager {

    private static FontManager instance;
    private Font proxima;
    private Font assetsio;
    private Font proximaBold;
    private Font minecraftFallback;
    private boolean fontReady;

    private FontManager() {
        try {
            proxima     = loadTTF("/assets/" + SmellyDihh.ID + "/fonts/proxima.ttf", 20f);
            proximaBold = loadTTF("/assets/" + SmellyDihh.ID + "/fonts/proximabd.ttf", 20f);
            assetsio    = loadTTF("/assets/" + SmellyDihh.ID + "/fonts/assetsio.ttf", 32f);
            fontReady   = proxima != null;
        } catch (Throwable t) {
            System.err.println("[SmellyDihh] Custom fonts failed to load: " + t);
        }
        minecraftFallback = new Font(Font.SANS_SERIF, Font.PLAIN, 16);
    }

    public static FontManager instance() {
        if (instance == null) instance = new FontManager();
        return instance;
    }

    private Font loadTTF(String path, float size) {
        try (InputStream in = FontManager.class.getResourceAsStream(path)) {
            if (in == null) return null;
            return Font.createFont(Font.TRUETYPE_FONT, in).deriveFont(size);
        } catch (IOException | FontFormatException e) { return null; }
    }

    public boolean isReady() { return fontReady; }
    public Font getProxima()      { return proxima     != null ? proxima     : minecraftFallback; }
    public Font getProximaBold()  { return proximaBold != null ? proximaBold : getProxima(); }
    public Font getAssetsio()     { return assetsio    != null ? assetsio    : getProxima(); }

    /** Measure text width in pixels for a given font + size. */
    public int getStringWidth(String text, Font font, float size) {
        if (text == null) return 0;
        BufferedImage tmp = new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = tmp.createGraphics();
        g.setFont(font.deriveFont(size));
        int w = g.getFontMetrics().stringWidth(text);
        g.dispose();
        return w;
    }

    public int getStringHeight(Font font, float size) {
        BufferedImage tmp = new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = tmp.createGraphics();
        g.setFont(font.deriveFont(size));
        int h = g.getFontMetrics().getHeight();
        g.dispose();
        return h;
    }

    /**
     * Render text directly as a bitmap (used in previews / splash fallback).
     * In-game HUD/ClickGUI use Minecraft's GuiScreen.drawString which we call
     * via reflection so we don't pull in mapping-specific imports.
     */
    public BufferedImage renderText(String text, Font font, float size, Color color, boolean shadow) {
        Font f = font.deriveFont(size);
        java.awt.Color awt = new java.awt.Color(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
        BufferedImage tmp = new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = tmp.createGraphics();
        g.setFont(f);
        int w = g.getFontMetrics().stringWidth(text) + (shadow ? 2 : 0);
        int h = g.getFontMetrics().getHeight();
        g.dispose();
        BufferedImage img = new BufferedImage(Math.max(1,w), Math.max(1,h), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g2.setFont(f);
        int y = g2.getFontMetrics().getAscent();
        if (shadow) {
            g2.setColor(new java.awt.Color(0,0,0, color.getAlpha()));
            g2.drawString(text, 1, y+1);
        }
        g2.setColor(awt);
        g2.drawString(text, 0, y);
        g2.dispose();
        return img;
    }
}
