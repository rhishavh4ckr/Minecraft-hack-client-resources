package net.smellydihh.client.modules.render;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class Fullbright extends Module {
    public Fullbright() { super("Fullbright", "See in the dark.", Category.RENDER, 71 /* G */); }
}
