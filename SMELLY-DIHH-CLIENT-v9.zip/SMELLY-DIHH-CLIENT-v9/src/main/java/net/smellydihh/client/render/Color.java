package net.smellydihh.client.render;

/** Immutable ARGB color with helpers. */
public final class Color {
    private final int argb;
    public Color(int argb) { this.argb = argb; }
    public Color(int r, int g, int b, int a) { this.argb = ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF); }
    public Color(int r, int g, int b) { this(r,g,b,255); }

    public int getARGB()   { return argb; }
    public int getRed()    { return (argb >> 16) & 0xFF; }
    public int getGreen()  { return (argb >>  8) & 0xFF; }
    public int getBlue()   { return argb & 0xFF; }
    public int getAlpha()  { return (argb >> 24) & 0xFF; }
    public float getRedF()   { return getRed()   / 255f; }
    public float getGreenF() { return getGreen() / 255f; }
    public float getBlueF()  { return getBlue()  / 255f; }
    public float getAlphaF() { return getAlpha() / 255f; }

    public Color withAlpha(int a) { return new Color(getRed(), getGreen(), getBlue(), a); }
    public Color brighter(float amt) {
        int r = Math.min(255, (int)(getRed()   + 255*amt));
        int g = Math.min(255, (int)(getGreen() + 255*amt));
        int b = Math.min(255, (int)(getBlue()  + 255*amt));
        return new Color(r,g,b,getAlpha());
    }
    public Color darker(float amt) {
        int r = Math.max(0, (int)(getRed()   - 255*amt));
        int g = Math.max(0, (int)(getGreen() - 255*amt));
        int b = Math.max(0, (int)(getBlue()  - 255*amt));
        return new Color(r,g,b,getAlpha());
    }

    /** Interpolate between this color and another (0= this, 1= other). */
    public Color lerp(Color o, float t) {
        float u = 1f - t;
        return new Color(
            (int)(getRed()*u   + o.getRed()*t),
            (int)(getGreen()*u + o.getGreen()*t),
            (int)(getBlue()*u  + o.getBlue()*t),
            (int)(getAlpha()*u + o.getAlpha()*t));
    }

    public static final Color WHITE = new Color(255,255,255);
    public static final Color BLACK = new Color(0,0,0);
    public static final Color RED   = new Color(255,0,0);
    public static final Color GREEN = new Color(0,255,0);
    public static final Color BLUE  = new Color(0,0,255);
    public static final Color TRANSPARENT = new Color(0,0,0,0);

    @Override public boolean equals(Object o) { return o instanceof Color && ((Color)o).argb == argb; }
    @Override public int hashCode() { return argb; }
    @Override public String toString() { return String.format("#%08X", argb); }
}
