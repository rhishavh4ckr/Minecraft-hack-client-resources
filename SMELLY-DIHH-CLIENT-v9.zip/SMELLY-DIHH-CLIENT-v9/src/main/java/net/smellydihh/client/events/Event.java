package net.smellydihh.client.events;

/**
 * Base type for all events dispatched through the client event bus.
 * Subclasses may be extended with their own data fields.
 */
public abstract class Event {

    private boolean cancelled;
    private Era era = Era.PRE;

    public boolean isCancelled() { return cancelled; }

    /** Cancellation is only respected for events that implement {@link Cancellable}. */
    public void setCancelled(boolean cancelled) {
        if (this instanceof Cancellable) this.cancelled = cancelled;
    }

    public Era getEra() { return era; }
    public void setEra(Era era) { this.era = era; }

    public enum Era { PRE, POST }

    /** Marker interface for events that may be cancelled. */
    public interface Cancellable { }
}
