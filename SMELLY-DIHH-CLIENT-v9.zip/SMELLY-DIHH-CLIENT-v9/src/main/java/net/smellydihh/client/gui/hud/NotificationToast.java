package net.smellydihh.client.gui.hud;

public final class NotificationToast {
    public final String title;
    public final String message;
    public final long lifetime;
    public final long created = System.currentTimeMillis();
    public NotificationToast(String t, String m, long life) { title=t; message=m; lifetime=life; }
    public boolean isExpired() { return System.currentTimeMillis() - created > lifetime; }
}
