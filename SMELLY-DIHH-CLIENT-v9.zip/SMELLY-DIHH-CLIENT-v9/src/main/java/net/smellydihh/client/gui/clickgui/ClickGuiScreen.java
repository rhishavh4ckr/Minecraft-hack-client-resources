package net.smellydihh.client.gui.clickgui;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.events.EventBus;
import net.smellydihh.client.events.KeyEvent;
import net.smellydihh.client.events.Render2DEvent;
import net.smellydihh.client.font.FontManager;
import net.smellydihh.client.gui.hud.HudRenderer;
import net.smellydihh.client.theme.ThemeManager;
import net.smellydihh.client.util.reflect.Reflection;

/**
 * Handles opening/closing the ClickGUI on the RIGHT_SHIFT key.
 * When active, the GUI is drawn on {@link Render2DEvent} and we
 * consume keyboard/mouse input to prevent leakage into the game.
 *
 * <p>The screen is NOT a subclass of Minecraft's GuiScreen – instead we
 * draw directly on the {@link Render2DEvent} (like LiquidBounce's
 * ClickGUI) so we work across all loaders without depending on
 * mapping-specific superclasses.
 */
public class ClickGuiScreen {

    private static ClickGuiScreen instance;
    public static ClickGuiScreen instance() {
        if (instance == null) instance = new ClickGuiScreen();
        return instance;
    }

    private final ClickGui gui = new ClickGui();
    private boolean open = false;

    private ClickGuiScreen() {
        EventBus.get().register(new Listener());
    }

    public boolean isOpen() { return open; }

    public void toggle() {
        open = !open;
        if (open) {
            gui.open();
            releaseMouseIfNeeded();
        } else {
            gui.close();
            grabMouseIfNeeded();
        }
    }

    public void open() { if (!open) toggle(); }
    public void close() { if (open) toggle(); }

    private void releaseMouseIfNeeded() {
        Object mc = net.smellydihh.client.util.MinecraftBridge.getMinecraft();
        if (mc == null) return;
        // set screen to null? No – we want to ungrab the mouse.
        for (String m : new String[]{"setIngameNotInFocus", "func_71384_b", "c", "mouseHelper"}) {
            try { Reflection.invoke(mc, m); } catch (Throwable ignored) {}
        }
    }

    private void grabMouseIfNeeded() {
        Object mc = net.smellydihh.client.util.MinecraftBridge.getMinecraft();
        if (mc == null) return;
        for (String m : new String[]{"setIngameFocus", "func_71385_c", "d", "g"}) {
            try { Reflection.invoke(mc, m); } catch (Throwable ignored) {}
        }
    }

    private final class Listener implements EventBus.EventSubscriber {
        @EventBus.Handler
        public void onRender(Render2DEvent e) {
            // Always let HUD render
            HudRenderer.instance().render(e.getScreenWidth(), e.getScreenHeight(), e.getPartialTicks());
            if (open) {
                gui.render(getMouseX(), getMouseY(), e.getPartialTicks());
            }
        }

        @EventBus.Handler
        public void onKey(KeyEvent e) {
            if (e.isPress() && e.getKey() == SmellyDihh.CLICK_GUI_KEY) {
                toggle();
                e.setCancelled(true);
                return;
            }
            if (open && e.isPress()) {
                // Backspace / char handling in ClickGui done via char callbacks (we wire this at start-up)
            }
        }
    }

    private int getMouseX() {
        Object mc = net.smellydihh.client.util.MinecraftBridge.getMinecraft();
        if (mc == null) return 0;
        for (String f : new String[]{"field_1775", "displayWidth", "getMouseX", "method_1591"}) {
            try {
                Object v = Reflection.getMember(mc, f);
                if (v instanceof Number) return ((Number)v).intValue();
            } catch (Throwable ignored) {}
        }
        return 0;
    }
    private int getMouseY() {
        Object mc = net.smellydihh.client.util.MinecraftBridge.getMinecraft();
        if (mc == null) return 0;
        for (String f : new String[]{"field_1776","displayHeight","getMouseY","method_1592"}) {
            try {
                Object v = Reflection.getMember(mc, f);
                if (v instanceof Number) return ((Number)v).intValue();
            } catch (Throwable ignored) {}
        }
        return 0;
    }
}
