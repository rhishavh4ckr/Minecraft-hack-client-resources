package net.smellydihh.client.events;

/**
 * Fired every frame after the Minecraft GUI is drawn, with partial ticks so
 * HUD elements can animate smoothly. Listeners can draw 2D content using
 * the {@link net.smellydihh.client.render.Render2D} helpers.
 */
public class Render2DEvent extends Event {
    private final float partialTicks;
    private final int screenWidth;
    private final int screenHeight;

    public Render2DEvent(float partialTicks, int screenWidth, int screenHeight) {
        this.partialTicks = partialTicks;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
    }
    public float getPartialTicks() { return partialTicks; }
    public int getScreenWidth()   { return screenWidth; }
    public int getScreenHeight()  { return screenHeight; }
}
