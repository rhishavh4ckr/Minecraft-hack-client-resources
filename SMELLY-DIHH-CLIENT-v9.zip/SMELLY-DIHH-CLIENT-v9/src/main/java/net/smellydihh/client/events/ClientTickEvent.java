package net.smellydihh.client.events;

/** Fired on the in-game tick loop (20 times per second). */
public class ClientTickEvent extends Event {
    public enum Phase { PRE, POST }
    private final Phase phase;
    public ClientTickEvent(Phase phase) { this.phase = phase; }
    public Phase getPhase() { return phase; }
}
