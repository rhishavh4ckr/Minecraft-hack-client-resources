package net.smellydihh.client.modules.movement;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class Jesus extends Module {
    public Jesus() { super("Jesus", "Walk on water.", Category.MOVEMENT, 74 /* J */); }
}
