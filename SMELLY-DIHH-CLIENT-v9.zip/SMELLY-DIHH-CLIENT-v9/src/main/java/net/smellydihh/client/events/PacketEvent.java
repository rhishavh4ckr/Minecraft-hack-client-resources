package net.smellydihh.client.events;

/** Fired when a network packet is being sent or received. */
public class PacketEvent extends Event implements Event.Cancellable {
    private final Direction direction;
    private Object packet;
    public PacketEvent(Direction direction, Object packet) { this.direction = direction; this.packet = packet; }
    public Direction getDirection() { return direction; }
    public Object getPacket()       { return packet; }
    public void setPacket(Object p) { this.packet = p; }
    public enum Direction { SEND, RECEIVE }
}
