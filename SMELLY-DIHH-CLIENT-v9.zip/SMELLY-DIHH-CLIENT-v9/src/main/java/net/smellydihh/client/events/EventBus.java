package net.smellydihh.client.events;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * High-performance, reflection-based event bus.
 *
 * <p>Listeners subscribe via {@link EventSubscriber} methods tagged with
 * {@link Handler}, and the bus dispatches by walking a pre-sorted list of
 * handlers for the event type. Cancellable events stop further dispatch to
 * lower-priority listeners when cancelled.
 */
public final class EventBus {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface Handler {
        int priority() default 0;
    }

    /** Marker interface for classes that contain @Handler methods. */
    public interface EventSubscriber { }

    public static final int PRIORITY_HIGHEST =  100;
    public static final int PRIORITY_HIGH    =   50;
    public static final int PRIORITY_DEFAULT =    0;
    public static final int PRIORITY_LOW     =  -50;
    public static final int PRIORITY_LOWEST  = -100;

    private static final class RegisteredHandler {
        final Object owner;
        final Method method;
        final Class<?> eventType;
        final int priority;
        RegisteredHandler(Object owner, Method method, Class<?> eventType, int priority) {
            this.owner = owner; this.method = method; this.eventType = eventType; this.priority = priority;
        }
    }

    /** Map: event class -> list of handlers (sorted by priority descending). */
    private final Map<Class<?>, List<RegisteredHandler>> handlers = new ConcurrentHashMap<>();
    private final List<Object> subscribers = new CopyOnWriteArrayList<>();

    public void register(Object subscriber) {
        Objects.requireNonNull(subscriber);
        if (subscribers.contains(subscriber)) return;
        subscribers.add(subscriber);
        for (Method m : subscriber.getClass().getDeclaredMethods()) {
            Handler h = m.getAnnotation(Handler.class);
            if (h == null) continue;
            if (m.getParameterCount() != 1) continue;
            Class<?> evtType = m.getParameterTypes()[0];
            if (!Event.class.isAssignableFrom(evtType)) continue;
            m.setAccessible(true);
            handlers.computeIfAbsent(evtType, k -> new CopyOnWriteArrayList<>())
                    .add(new RegisteredHandler(subscriber, m, evtType, h.priority()));
            // re-sort by priority descending
            handlers.get(evtType).sort(Comparator.comparingInt((RegisteredHandler rh) -> rh.priority).reversed());
        }
    }

    public void unregister(Object subscriber) {
        subscribers.remove(subscriber);
        for (List<RegisteredHandler> list : handlers.values()) {
            list.removeIf(rh -> rh.owner == subscriber);
        }
    }

    public <E extends Event> E post(E event) {
        Class<?> type = event.getClass();
        List<RegisteredHandler> list = handlers.get(type);
        if (list != null) {
            for (RegisteredHandler rh : list) {
                if (event instanceof Event.Cancellable && event.isCancelled()) break;
                try { rh.method.invoke(rh.owner, event); }
                catch (Throwable t) { handleException(rh, event, t); }
            }
        }
        // Also dispatch to superclass listeners (so a TickEvent listener receives all tick sub-types).
        Class<?> sup = type.getSuperclass();
        while (sup != null && Event.class.isAssignableFrom(sup)) {
            List<RegisteredHandler> supList = handlers.get(sup);
            if (supList != null) {
                for (RegisteredHandler rh : supList) {
                    if (event instanceof Event.Cancellable && event.isCancelled()) break;
                    try { rh.method.invoke(rh.owner, event); }
                    catch (Throwable t) { handleException(rh, event, t); }
                }
            }
            sup = sup.getSuperclass();
        }
        return event;
    }

    private void handleException(RegisteredHandler rh, Event event, Throwable t) {
        Throwable cause = t.getCause() != null ? t.getCause() : t;
        System.err.println("[SmellyDihh] Event handler error: " + rh.method + " on " + event.getClass().getSimpleName());
        cause.printStackTrace();
    }

    // ---------------- Singleton ----------------
    private static final EventBus INSTANCE = new EventBus();
    public static EventBus get() { return INSTANCE; }
    private EventBus() { }
}
