package net.smellydihh.client.modules.player;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class Blink extends Module {
    public Blink() { super("Blink", "Holds packets until disabled.", Category.PLAYER, 0); }
}
