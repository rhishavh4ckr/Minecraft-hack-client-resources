package net.smellydihh.client.modules.misc;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class FastChat extends Module {
    public FastChat() { super("FastChat", "Remove chat cooldown.", Category.MISC, 0); }
}
