package net.smellydihh.client.config;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.core.ModuleManager;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.*;
import net.smellydihh.client.theme.ThemeManager;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public final class ConfigManager {
    private static ConfigManager instance;
    public static ConfigManager instance() { if (instance==null) instance = new ConfigManager(); return instance; }

    private Path dir;

    public void init() {
        String home = System.getProperty("user.home", ".");
        dir = Paths.get(home, ".minecraft", SmellyDihh.CONFIG_FOLDER);
        try { Files.createDirectories(dir); } catch (IOException ignored) {}
    }

    public Path getConfigDir() {
        if (dir == null) init();
        return dir;
    }

    public void save(String name) {
        JSONObject root = new JSONObject();
        root.put("client", SmellyDihh.NAME);
        root.put("version", SmellyDihh.VERSION);
        root.put("theme", ThemeManager.instance().getActive().name);
        JSONArray mods = new JSONArray();
        for (Module m : ModuleManager.instance().getModules()) {
            JSONObject jm = new JSONObject();
            jm.put("name", m.getName());
            jm.put("enabled", m.isEnabled());
            jm.put("key", m.getKey());
            JSONArray sets = new JSONArray();
            for (Setting<?> s : m.getSettings()) {
                JSONObject js = new JSONObject();
                js.put("name", s.getName());
                if (s instanceof BooleanSetting) js.put("value", ((BooleanSetting)s).getValue());
                else if (s instanceof NumberSetting) js.put("value", ((NumberSetting)s).getValue());
                else if (s instanceof ModeSetting) js.put("value", ((ModeSetting)s).getMode());
                else if (s instanceof KeybindSetting) js.put("value", ((KeybindSetting)s).getValue());
                else js.put("value", String.valueOf(s.getValue()));
                sets.put(js);
            }
            jm.put("settings", sets);
            mods.put(jm);
        }
        root.put("modules", mods);
        try (Writer w = Files.newBufferedWriter(dir.resolve(name + ".json"), StandardCharsets.UTF_8)) {
            w.write(root.toString(2));
        } catch (IOException ex) { ex.printStackTrace(); }
    }

    public void load(String name) {
        Path p = dir.resolve(name + ".json");
        if (!Files.exists(p)) return;
        try {
            String txt = new String(Files.readAllBytes(p), StandardCharsets.UTF_8);
            JSONObject root = new JSONObject(txt);
            JSONArray mods = root.optJSONArray("modules");
            if (mods != null) {
                for (int i = 0; i < mods.length(); i++) {
                    JSONObject jm = mods.getJSONObject(i);
                    Module m = ModuleManager.instance().getByName(jm.getString("name"));
                    if (m == null) continue;
                    if (jm.optBoolean("enabled", false)) m.enable(); else m.disable();
                }
            }
            ThemeManager.instance().setActive(root.optString("theme", ThemeManager.instance().getActive().name));
        } catch (Exception ex) { ex.printStackTrace(); }
    }

    public void saveDefault() { if (!Files.exists(dir.resolve("default.json"))) save("default"); }
    public void loadDefault() { load("default"); }
    public void autoSave() { save("autosave"); }
    public void autoLoad() { load("autosave"); }
}
