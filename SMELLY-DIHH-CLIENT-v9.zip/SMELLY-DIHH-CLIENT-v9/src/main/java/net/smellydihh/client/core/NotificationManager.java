package net.smellydihh.client.core;

import net.smellydihh.client.gui.hud.NotificationToast;

import java.util.ArrayDeque;
import java.util.Deque;

public final class NotificationManager {
    private static NotificationManager instance;
    public static NotificationManager instance() { if (instance==null) instance=new NotificationManager(); return instance; }
    private final Deque<NotificationToast> queue = new ArrayDeque<>();
    public void post(String title, String message, long ms) { queue.add(new NotificationToast(title, message, ms)); }
    public void post(String title, String message) { post(title, message, 2500); }
    public Deque<NotificationToast> getQueue() { return queue; }
}
