package net.smellydihh.client.modules.player;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class NoRotate extends Module {
    public NoRotate() { super("NoRotate", "Prevents forced rotations.", Category.PLAYER, 0); }
}
