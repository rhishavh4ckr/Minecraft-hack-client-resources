package net.smellydihh.client.settings;

import java.util.Arrays;
import java.util.List;

/**
 * String-array mode setting. Stores the index and exposes the selected label.
 */
public class ModeSetting extends Setting<Integer> {
    private final List<String> modes;
    public ModeSetting(String name, String description, int defaultIndex, String... modes) {
        super(name, description, defaultIndex);
        this.modes = Arrays.asList(modes);
    }
    public List<String> getModes() { return modes; }
    public String getMode() {
        int idx = getValue();
        if (idx < 0 || idx >= modes.size()) idx = 0;
        return modes.get(idx);
    }
    public void setMode(String s) {
        int i = modes.indexOf(s);
        if (i >= 0) setValue(i);
    }
    public void cycle() { setValue((getValue() + 1) % modes.size()); }
    @Override protected Integer clamp(Integer v) { return v == null ? 0 : Math.max(0, Math.min(modes.size() - 1, v)); }
}
