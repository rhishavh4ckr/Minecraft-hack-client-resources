package net.smellydihh.client.settings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** A collapsible group of settings rendered under a sub-heading. */
public class SettingGroup {
    private final String name;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean expanded = true;

    public SettingGroup(String name, Setting<?>... settings) {
        this.name = name;
        this.settings.addAll(Arrays.asList(settings));
    }
    public String getName()              { return name; }
    public List<Setting<?>> getSettings() { return settings; }
    public boolean isExpanded()          { return expanded; }
    public void setExpanded(boolean e)   { this.expanded = e; }
    public void toggle()                { this.expanded = !this.expanded; }
    public SettingGroup add(Setting<?> s) { settings.add(s); return this; }
}
