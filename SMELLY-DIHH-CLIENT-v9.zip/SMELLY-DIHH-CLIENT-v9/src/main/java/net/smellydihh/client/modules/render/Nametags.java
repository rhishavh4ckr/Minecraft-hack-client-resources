package net.smellydihh.client.modules.render;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.BooleanSetting;
import net.smellydihh.client.settings.NumberSetting;

public class Nametags extends Module {
    private final NumberSetting scale = new NumberSetting("Scale", "Name tag scale.", 1.2, 0.5, 3.0, 0.1);
    private final BooleanSetting health = new BooleanSetting("Health", "Show health bar.", true);
    private final BooleanSetting armor  = new BooleanSetting("Armor", "Show armor bar.", true);
    public Nametags() { super("Nametags", "Bigger/better name tags.", Category.RENDER, 0); addSetting(scale); addSetting(health); addSetting(armor); }
}
