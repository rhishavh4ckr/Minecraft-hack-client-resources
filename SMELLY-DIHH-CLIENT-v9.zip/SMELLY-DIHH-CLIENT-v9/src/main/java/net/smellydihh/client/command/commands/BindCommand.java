package net.smellydihh.client.command.commands;

import net.smellydihh.client.command.Command;
import net.smellydihh.client.command.CommandManager;
import net.smellydihh.client.core.ModuleManager;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.config.ConfigManager;
import net.smellydihh.client.theme.ThemeManager;

public class BindCommand implements Command {
    public String name() { return "bind"; }
    public String syntax() { return ".bind"; }
    public String description() { return "Bind command."; }
    public void execute(String[] args) {
        switch("bind") {
            case "help":
                CommandManager.sendMsg("Commands:");
                for (Command c : CommandManager.instance().getCommands())
                    CommandManager.sendMsg("  " + c.syntax() + " - " + c.description());
                break;
            case "toggle":
                if (args.length == 0) { CommandManager.sendError("Usage: .toggle <module>"); return; }
                Module m = ModuleManager.instance().getByName(String.join(" ",args));
                if (m == null) { CommandManager.sendError("Module not found"); return; }
                m.toggle();
                CommandManager.sendMsg((m.isEnabled()?"Enabled ":"Disabled ") + m.getName());
                break;
            case "bind":
                if (args.length < 2) { CommandManager.sendError("Usage: .bind <module> <key>"); return; }
                Module mm = ModuleManager.instance().getByName(args[0]);
                if (mm == null) { CommandManager.sendError("Module not found"); return; }
                CommandManager.sendMsg("Bound " + mm.getName() + " (press the desired key in GUI)");
                break;
            case "config":
                if (args.length == 0) { ConfigManager.instance().autoSave(); CommandManager.sendMsg("Saved autosave."); return; }
                if (args[0].equalsIgnoreCase("save") && args.length>=2) ConfigManager.instance().save(args[1]);
                else if (args[0].equalsIgnoreCase("load") && args.length>=2) ConfigManager.instance().load(args[1]);
                else CommandManager.sendError("Usage: .config <save|load> <name>");
                break;
            case "theme":
                if (args.length == 0) {
                    CommandManager.sendMsg("Themes: " + ThemeManager.instance().getThemes().size());
                    return;
                }
                ThemeManager.instance().setActive(args[0]);
                CommandManager.sendMsg("Theme: " + ThemeManager.instance().getActive().name);
                break;
        }
    }
}
