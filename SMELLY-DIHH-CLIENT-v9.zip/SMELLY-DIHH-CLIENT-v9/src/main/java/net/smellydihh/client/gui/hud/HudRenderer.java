package net.smellydihh.client.gui.hud;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.core.ModuleManager;
import net.smellydihh.client.events.EventBus;
import net.smellydihh.client.events.Render2DEvent;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.render.Color;
import net.smellydihh.client.render.Render2D;
import net.smellydihh.client.theme.Theme;
import net.smellydihh.client.theme.ThemeManager;
import net.smellydihh.client.util.MinecraftBridge;
import net.smellydihh.client.util.reflect.Reflection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * VAPE v4 inspired HUD renderer.
 * Draws the watermark + ArrayList of enabled modules with the orange→red
 * vertical accent rail, shadow text, and Proxima Nova font.
 */
public class HudRenderer {

    private static HudRenderer instance;
    public static HudRenderer instance() {
        if (instance == null) instance = new HudRenderer();
        return instance;
    }

    public void register() {
        EventBus.get().register(new Listener());
    }

    // Optional HUD element extensions (kept simple for now).
    private boolean arrayList = true;
    private boolean watermark = true;
    private boolean showKeys = true;

    public boolean isArrayListEnabled() { return arrayList; }
    public void setArrayList(boolean v)  { this.arrayList = v; }
    public boolean isWatermarkEnabled()  { return watermark; }
    public void setWatermark(boolean v)  { this.watermark = v; }

    private static final class Listener implements EventBus.EventSubscriber {
        @EventBus.Handler
        public void onRender2D(Render2DEvent e) {
            HudRenderer.instance().render(e.getScreenWidth(), e.getScreenHeight(), e.getPartialTicks());
        }
    }

    public void render(int screenWidth, int screenHeight, float pt) {
        Theme t = ThemeManager.instance().getActive();

        Render2D.enableBlend();

        if (watermark) drawWatermark(4, 4, t);

        if (arrayList) drawArrayList(screenWidth - 4, 4, t, pt);
    }

    // ---------------- Watermark ----------------
    private void drawWatermark(int x, int y, Theme t) {
        String line1 = SmellyDihh.NAME;
        String line2 = "v" + SmellyDihh.VERSION + " [" + SmellyDihh.BUILD + "]";

        // Use Minecraft's font renderer if possible for crisp text.
        Object fr = getFontRenderer();
        int h1 = 10, w1, w2;
        if (fr != null) {
            w1 = (int) Reflection.invoke(fr, "getStringWidth", line1);
            w2 = (int) Reflection.invoke(fr, "getStringWidth", line2);
            drawMcString(fr, line1, x, y, t.watermark.getARGB(), true);
            drawMcString(fr, line2, x, y + 11, t.textSecondary.getARGB(), true);
        } else {
            // Fallback: just draw a filled rect representing watermark area
            w1 = 80; w2 = 60;
            Render2D.fillRect(x, y, w1, 10, t.watermark);
        }
        // subtle line under watermark
        Render2D.fillRect(x, y + (fr != null ? 22 : 14), Math.max(w1, w2), 1, t.accent);
    }

    // ---------------- VAPE ArrayList ----------------
    private void drawArrayList(int rightX, int topY, Theme t, float pt) {
        List<Module> enabled = new ArrayList<>(ModuleManager.instance().getEnabled());
        // Sort by display-name width DESC (widest on top) then by toggle time
        Object fr = getFontRenderer();
        enabled.sort(Comparator.<Module>comparingInt(m -> -stringWidth(fr, m.getName()))
                .thenComparingLong(Module::getLastToggledTime).reversed());

        int y = topY;
        int textH = fr != null ? 10 : 12;
        int margin = 3;

        for (Module m : enabled) {
            if (m.isHidden()) continue;
            String label = m.getName();
            if (showKeys && m.getKey() != 0) label += " [" + keyName(m.getKey()) + "]";
            int tw = stringWidth(fr, label);
            int bgX = rightX - tw - margin*2 - 2; // 2 = rail width
            int bgY = y;

            // Background
            Render2D.fillRect(bgX + 2, bgY, tw + margin*2, textH, t.hudBg);
            // Accent rail (orange top → red bottom gradient)
            Render2D.drawAccentRail(bgX, bgY, textH, t.hudRailTop, t.hudRailBottom);
            // Text (shadow then primary)
            if (fr != null) {
                drawMcString(fr, label, bgX + 2 + margin, bgY + 1, t.hudTextShadow.getARGB(), false);
                drawMcString(fr, label, bgX + 2 + margin - 1, bgY, m.getCategory().getAccentColor(), true);
            } else {
                Render2D.fillRect(bgX + 2 + margin, bgY + 2, tw, textH - 4, Color.WHITE);
            }
            y += textH + 1;
        }
    }

    // ---------------- Font helpers ----------------
    private static Object getFontRenderer() {
        Object mc = MinecraftBridge.getMinecraft();
        if (mc == null) return null;
        for (String f : new String[]{"fontRendererObj", "fontRenderer", "field_71466_p", "method_1561", "a", "getFontRenderer"}) {
            try { return Reflection.getMember(mc, f); } catch (Throwable ignored) {}
        }
        return null;
    }

    private static int stringWidth(Object fr, String s) {
        if (fr == null) return s.length() * 6;
        Object w = Reflection.invoke(fr, "getStringWidth", s);
        if (w instanceof Number) return ((Number) w).intValue();
        return s.length() * 6;
    }

    private static void drawMcString(Object fr, String s, int x, int y, int color, boolean dropShadow) {
        if (fr == null) return;
        String method = dropShadow ? "drawStringWithShadow" : "drawString";
        for (String m : new String[]{method, "func_78255_a", "a", "draw"}) {
            try {
                Reflection.invoke(fr, m, s, (double)x, (double)y, (double)color);
                return;
            } catch (Throwable ignored) {}
        }
        // Try int overloads
        try {
            java.lang.reflect.Method dm = fr.getClass().getMethod("drawString", String.class, int.class, int.class, int.class, boolean.class);
            dm.setAccessible(true);
            dm.invoke(fr, s, x, y, color, dropShadow);
            return;
        } catch (Throwable ignored) {}
    }

    private static String keyName(int key) {
        // LWJGL key codes; covers common bindings.
        switch (key) {
            case 54: return "RSHIFT";
            case 42: return "LSHIFT";
            case 29: return "LCTRL";
            case 157:return "RCTRL";
            case 56: return "LALT";
            case 184:return "RALT";
            case 1:  return "ESC";
            case 199:return "HOME";
            case 207:return "END";
            case 200:return "UP";
            case 208:return "DOWN";
            case 203:return "LEFT";
            case 205:return "RIGHT";
            case 28: return "ENTER";
            case 15: return "TAB";
            case 57: return "SPACE";
            default:
                if (key >= 2 && key <= 11) return "M" + (key-1);
                if (key >= 16 && key <= 27) return "Q" + (key-16);
                if (key >= 30 && key <= 40) return Character.toString((char)('A' + (key-30)));
                if (key >= 2 && key <= 13)  return "MOUSE" + (key-1); // mouse buttons
                return "K"+key;
        }
    }
}
