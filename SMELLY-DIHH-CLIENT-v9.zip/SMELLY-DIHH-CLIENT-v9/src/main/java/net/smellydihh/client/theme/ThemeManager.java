package net.smellydihh.client.theme;

import java.util.ArrayList;
import java.util.List;

/** Holds the list of available themes and the currently-active one. */
public final class ThemeManager {
    private static ThemeManager instance;
    private final List<Theme> themes = new ArrayList<>();
    private Theme active;
    private final List<Runnable> listeners = new ArrayList<>();

    private ThemeManager() {
        themes.add(Theme.smellyDihhDefault());
        active = themes.get(0);
    }
    public static ThemeManager instance() {
        if (instance == null) instance = new ThemeManager();
        return instance;
    }
    public Theme getActive() { return active; }
    public void setActive(Theme t) { this.active = t; listeners.forEach(Runnable::run); }
    public void setActive(String name) {
        for (Theme t : themes) if (t.name.equalsIgnoreCase(name)) { setActive(t); return; }
    }
    public List<Theme> getThemes() { return themes; }
    public void register(Theme t) { themes.add(t); }
    public void addChangeListener(Runnable r) { listeners.add(r); }
}
