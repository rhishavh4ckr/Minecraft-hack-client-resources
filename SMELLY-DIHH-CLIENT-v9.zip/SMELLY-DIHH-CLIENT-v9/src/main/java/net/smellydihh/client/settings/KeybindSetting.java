package net.smellydihh.client.settings;

/** Stores an LWJGL key code (see GLFW key tokens; RIGHT_SHIFT = 34888889? no – LWJGL2 uses 54). */
public class KeybindSetting extends Setting<Integer> {
    private boolean listening;
    public KeybindSetting(String name, String description, int defaultKey) { super(name, description, defaultKey); }
    public int getKey() { return getValue(); }
    public boolean isListening() { return listening; }
    public void setListening(boolean l) { this.listening = l; }
    public boolean matches(int key) { return getValue() != 0 && getValue() == key; }
}
