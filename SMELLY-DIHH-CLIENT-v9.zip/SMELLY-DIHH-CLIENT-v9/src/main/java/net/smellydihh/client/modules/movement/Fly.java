package net.smellydihh.client.modules.movement;

import net.smellydihh.client.events.ClientTickEvent;
import net.smellydihh.client.events.EventBus;
import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.ModeSetting;
import net.smellydihh.client.settings.NumberSetting;
import net.smellydihh.client.util.MinecraftBridge;
import net.smellydihh.client.util.reflect.Reflection;

public class Fly extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Flight mode.", 0, "Vanilla", "Creative", "Motion");
    private final NumberSetting speed = new NumberSetting("Speed", "Fly speed.", 1.0, 0.1, 10.0, 0.1);
    public Fly() { super("Fly", "Allows you to fly like in creative.", Category.MOVEMENT, 33); addSetting(mode); addSetting(speed); }

    @Override protected void onEnable() {
        Object player = MinecraftBridge.getPlayer();
        if (player == null) return;
        Reflection.setMember(player, "onGround", true);
    }

    @EventBus.Handler
    public void onTick(ClientTickEvent e) {
        Object player = MinecraftBridge.getPlayer();
        if (player == null) return;
        switch (mode.getMode()) {
            case "Creative":
                Reflection.invoke(player, "capabilities/flySpeed", speed.getFloat());
                break;
            default:
                Reflection.setMember(player, "motionY", 0.0);
                Reflection.setMember(player, "onGround", true);
        }
    }
}
