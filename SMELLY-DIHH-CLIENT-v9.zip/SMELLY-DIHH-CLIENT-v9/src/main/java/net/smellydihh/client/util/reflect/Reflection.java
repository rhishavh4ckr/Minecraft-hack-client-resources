package net.smellydihh.client.util.reflect;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Reflection helpers with caching. We cannot rely on any single mapping set
 * because the bootstrap works as Forge/Fabric/LabyMod/agent, so every access
 * to Minecraft classes is done by searching for members by any of several
 * possible names (MCP, Searge, Intermediary, notch).
 */
public final class Reflection {

    private static final Map<String, Method> METHOD_CACHE = new ConcurrentHashMap<>();
    private static final Map<String, Field>  FIELD_CACHE  = new ConcurrentHashMap<>();

    private Reflection() { }

    // ---------------------------- Fields ----------------------------

    public static Field findField(Class<?> cls, String... names) throws NoSuchFieldException {
        Class<?> c = cls;
        while (c != null) {
            for (String n : names) {
                String key = c.getName() + "#" + n;
                Field f = FIELD_CACHE.get(key);
                if (f != null) return f;
                try {
                    f = c.getDeclaredField(n);
                    f.setAccessible(true);
                    FIELD_CACHE.put(key, f);
                    return f;
                } catch (NoSuchFieldException ignored) { }
            }
            c = c.getSuperclass();
        }
        throw new NoSuchFieldException("None of " + Arrays.toString(names) + " in " + cls.getName());
    }

    public static Object getFieldValue(Object inst, Class<?> cls, String... names) {
        try {
            Field f = findField(cls, names);
            return f.get(inst);
        } catch (Throwable t) { return null; }
    }

    public static void setFieldValue(Object inst, Class<?> cls, Object value, String... names) {
        try {
            Field f = findField(cls, names);
            f.set(inst, value);
        } catch (Throwable ignored) { }
    }

    /**
     * Tries field access, then getter methods (getXxx / isXxx / xxx) for a logical name.
     * Used by MinecraftBridge.getMember().
     */
    public static Object getMember(Object inst, String name) {
        Class<?> cls = inst.getClass();
        // try field
        try { Field f = findField(cls, name); return f.get(inst); } catch (Throwable ignored) { }
        // try getter
        String cap = name.length() > 1 ? Character.toUpperCase(name.charAt(0)) + name.substring(1) : name.toUpperCase();
        for (String prefix : new String[]{"get", "is", ""}) {
            String mn = prefix + (prefix.isEmpty() ? name : cap);
            try {
                Method m = findMethod(cls, mn);
                if (m.getParameterCount() == 0) return m.invoke(inst);
            } catch (Throwable ignored) { }
        }
        return null;
    }

    public static void setMember(Object inst, String name, Object value) {
        Class<?> cls = inst.getClass();
        try {
            Field f = findField(cls, name);
            f.set(inst, value);
            return;
        } catch (Throwable ignored) { }
        String cap = name.length() > 0 ? Character.toUpperCase(name.charAt(0)) + name.substring(1) : name;
        for (String prefix : new String[]{"set"}) {
            String mn = prefix + cap;
            try {
                Method m = findMethod(cls, mn, value == null ? Object.class : value.getClass());
                m.invoke(inst, value);
                return;
            } catch (Throwable ignored) { }
        }
    }

    // ---------------------------- Methods ---------------------------

    public static Method findMethod(Class<?> cls, String name, Class<?>... params) throws NoSuchMethodException {
        Class<?> c = cls;
        while (c != null) {
            String key = c.getName() + "#" + name + Arrays.toString(params);
            Method m = METHOD_CACHE.get(key);
            if (m != null) return m;
            for (Method cand : c.getDeclaredMethods()) {
                if (cand.getName().equals(name) && (params.length == 0 || Arrays.equals(cand.getParameterTypes(), params))) {
                    cand.setAccessible(true);
                    METHOD_CACHE.put(key, cand);
                    return cand;
                }
            }
            c = c.getSuperclass();
        }
        // Try by name only (parameter leniency)
        c = cls;
        while (c != null) {
            for (Method cand : c.getDeclaredMethods()) {
                if (cand.getName().equals(name) && cand.getParameterCount() == params.length) {
                    cand.setAccessible(true);
                    return cand;
                }
            }
            c = c.getSuperclass();
        }
        throw new NoSuchMethodException(name + "(" + Arrays.toString(params) + ") on " + cls.getName());
    }

    public static Object invoke(Object inst, String name, Object... args) {
        try {
            Class<?> cls = inst.getClass();
            Class<?>[] types = new Class<?>[args.length];
            for (int i = 0; i < args.length; i++) types[i] = args[i] == null ? Object.class : args[i].getClass();
            Method m = findMethod(cls, name, types);
            return m.invoke(inst, args);
        } catch (Throwable t) { return null; }
    }

    public static Object invokeStatic(Class<?> cls, String name, Object... args) {
        try {
            Class<?>[] types = new Class<?>[args.length];
            for (int i = 0; i < args.length; i++) types[i] = args[i] == null ? Object.class : args[i].getClass();
            Method m = findMethod(cls, name, types);
            return m.invoke(null, args);
        } catch (Throwable t) { return null; }
    }

    // ------------------------- Class helpers ------------------------

    public static Class<?> resolveClass(String... names) {
        for (String n : names) {
            try { return Class.forName(n); } catch (ClassNotFoundException ignored) { }
        }
        return null;
    }
}
