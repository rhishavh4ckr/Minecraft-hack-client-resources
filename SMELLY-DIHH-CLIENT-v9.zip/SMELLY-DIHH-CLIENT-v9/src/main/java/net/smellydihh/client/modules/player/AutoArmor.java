package net.smellydihh.client.modules.player;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class AutoArmor extends Module {
    public AutoArmor() { super("AutoArmor", "Auto-equips best armor.", Category.PLAYER, 0); }
}
