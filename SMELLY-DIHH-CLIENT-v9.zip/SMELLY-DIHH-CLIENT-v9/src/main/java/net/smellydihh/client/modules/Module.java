package net.smellydihh.client.modules;

import net.smellydihh.client.events.EventBus;
import net.smellydihh.client.events.EventBus.Handler;
import net.smellydihh.client.settings.Setting;
import net.smellydihh.client.settings.SettingGroup;
import net.smellydihh.client.settings.KeybindSetting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Base class for every cheat module. Modules self-register with the
 * {@link ModuleManager} on construction and auto-subscribe to the event bus
 * when enabled.
 */
public abstract class Module implements EventBus.EventSubscriber {

    private final String name;
    private final String description;
    private final Category category;
    private final KeybindSetting keybind;
    private boolean enabled;
    private boolean hidden;
    private int key;

    /** Sorting / display metadata for the ArrayList. */
    private long lastToggledTime = System.currentTimeMillis();

    private final List<Setting<?>> settings = new ArrayList<>();
    private final List<SettingGroup> groups  = new ArrayList<>();

    protected Module(String name, String description, Category category, int defaultKey) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.key = defaultKey;
        this.keybind = new KeybindSetting("Keybind", "Key that toggles this module.", defaultKey);
        this.settings.add(keybind);
    }

    // ---------------- Metadata ----------------
    public String getName()         { return name; }
    public String getDescription()  { return description; }
    public Category getCategory()   { return category; }
    public KeybindSetting getKeybindSetting() { return keybind; }
    public int getKey()             { return keybind.getValue(); }

    public boolean isEnabled() { return enabled; }
    public boolean isHidden()  { return hidden; }
    public void setHidden(boolean h) { this.hidden = h; }

    public List<Setting<?>> getSettings()      { return settings; }
    public List<SettingGroup> getGroups()      { return groups; }

    public long getLastToggledTime() { return lastToggledTime; }

    // ---------------- Toggle ----------------
    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        this.lastToggledTime = System.currentTimeMillis();
        if (enabled) {
            onEnable();
            EventBus.get().register(this);
        } else {
            EventBus.get().unregister(this);
            onDisable();
        }
    }

    public void enable()  { setEnabled(true); }
    public void disable() { setEnabled(false); }

    /** Called after the module is toggled on. Override to allocate resources. */
    protected void onEnable()  { }
    /** Called after the module is toggled off. Override to release resources. */
    protected void onDisable() { }

    /** Called every client tick while the module is enabled. Default no-op. */
    public void onTick() { }

    // ---------------- Settings helpers ----------------
    protected void addSetting(Setting<?> s) { settings.add(s); }
    protected SettingGroup addGroup(String name, Setting<?>... s) {
        SettingGroup g = new SettingGroup(name, s);
        groups.add(g);
        settings.addAll(Arrays.asList(s));
        return g;
    }

    /** Convenience – key-down helper for the keybind. */
    public boolean isKey(int k) { return keybind.matches(k); }

    @Override
    public String toString() { return name + "[" + category.getDisplayName() + "]"; }
}
