package net.smellydihh.client.modules.misc;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class AutoRespawn extends Module {
    public AutoRespawn() { super("AutoRespawn", "Respawn automatically on death.", Category.MISC, 0); }
}
