package net.smellydihh.client.modules.misc;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.events.EventBus;
import net.smellydihh.client.events.KeyEvent;
import net.smellydihh.client.gui.clickgui.ClickGuiScreen;
import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

/** Module that toggles the Click GUI. */
public class ClickGUIModule extends Module {
    public ClickGUIModule() {
        super("ClickGUI", "Toggles the Click GUI.", Category.CLIENT, SmellyDihh.CLICK_GUI_KEY);
        setHidden(true);
        EventBus.get().register(new Listener());
    }
    private final class Listener implements EventBus.EventSubscriber {
        @EventBus.Handler
        public void onKey(KeyEvent e) {
            if (e.isPress() && e.getKey() == getKey()) ClickGuiScreen.instance().toggle();
        }
    }
}
