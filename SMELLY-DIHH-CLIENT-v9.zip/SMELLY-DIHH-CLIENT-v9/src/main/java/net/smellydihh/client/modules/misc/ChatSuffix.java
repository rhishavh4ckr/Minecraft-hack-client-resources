package net.smellydihh.client.modules.misc;

import net.smellydihh.client.SmellyDihh;
import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.BooleanSetting;

public class ChatSuffix extends Module {
    private final BooleanSetting custom = new BooleanSetting("Fancy", "Use fancy symbols.", true);
    public ChatSuffix() { super("ChatSuffix", "Appends \u00a7a" + SmellyDihh.NAME + " suffix to messages.", Category.MISC, 0); addSetting(custom); }
}
