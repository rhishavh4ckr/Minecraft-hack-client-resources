package net.smellydihh.client.util;

import net.smellydihh.client.util.reflect.Reflection;

/**
 * Indirection layer for accessing the Minecraft game instance.
 * Uses reflection so the code is independent of any particular mapping set
 * (MCP, Searge, Intermediary, SRG, etc.) – we search for the class & getter
 * heuristically at start-up and cache the result.
 */
public final class MinecraftBridge {

    private static final String[] MC_CLASS_CANDIDATES = {
            "net.minecraft.client.Minecraft",         // MCP (1.8.9)
            "net.minecraft.class_310",                // Yarn / Intermediary
            "ave", "bib", "bie", "bip", "biq", "bir", // obfuscated (varies)
            "net.minecraft.client.MinecraftClient"    // newer Yarn
    };

    private static final String[] GET_INSTANCE_CANDIDATES = {
            "getMinecraft", "getInstance", "func_71410_x",
            "method_1552", "getInstance", "a"
    };

    private static Object minecraftInstance;
    private static Class<?> minecraftClass;
    private static boolean resolved;
    private static String resolutionError;

    private MinecraftBridge() { }

    /**
     * Locate and cache the Minecraft instance. Called once during bootstrap.
     */
    public static synchronized void init() {
        if (resolved) return;
        resolved = true;
        for (String clsName : MC_CLASS_CANDIDATES) {
            try {
                Class<?> cls = Class.forName(clsName);
                for (String methodName : GET_INSTANCE_CANDIDATES) {
                    try {
                        Object inst = Reflection.invokeStatic(cls, methodName);
                        if (inst != null) {
                            minecraftClass = cls;
                            minecraftInstance = inst;
                            return;
                        }
                    } catch (Throwable ignored) { }
                }
                // Check for a static field holding the instance
                for (String fName : new String[]{"field_1775", "theMinecraft", "INSTANCE", "a"}) {
                    try {
                        Object inst = Reflection.getFieldValue(null, cls, fName);
                        if (inst != null) {
                            minecraftClass = cls;
                            minecraftInstance = inst;
                            return;
                        }
                    } catch (Throwable ignored) { }
                }
            } catch (Throwable ignored) { }
        }
        resolutionError = "Minecraft class not found on classpath (non-game environment?).";
    }

    public static boolean isAvailable() { return minecraftInstance != null; }
    public static Object getMinecraft() { init(); return minecraftInstance; }
    public static Class<?> getMinecraftClass() { init(); return minecraftClass; }
    public static String getError() { return resolutionError; }

    /**
     * Convenience – fetch the local player from the Minecraft instance.
     * Tries multiple common field/getter names.
     */
    public static Object getPlayer() {
        Object mc = getMinecraft();
        if (mc == null) return null;
        String[] candidates = {"thePlayer", "player", "field_71439_g", "method_1547", "a", "getPlayer"};
        for (String f : candidates) {
            try { return Reflection.getMember(mc, f); } catch (Throwable ignored) { }
        }
        return null;
    }

    /**
     * Fetch the World/WorldClient instance.
     */
    public static Object getWorld() {
        Object mc = getMinecraft();
        if (mc == null) return null;
        String[] candidates = {"theWorld", "world", "field_71441_e", "method_1569", "getWorld"};
        for (String f : candidates) {
            try { return Reflection.getMember(mc, f); } catch (Throwable ignored) { }
        }
        return null;
    }

    /** Returns the partial-tick value used for smooth rendering. */
    public static float getPartialTicks() {
        Object mc = getMinecraft();
        if (mc == null) return 1.0f;
        for (String f : new String[]{"field_71428_T", "getRenderPartialTicks", "tickDelta", "method_1566", "b"}) {
            try {
                Object v = Reflection.getMember(mc, f);
                if (v instanceof Number) return ((Number) v).floatValue();
            } catch (Throwable ignored) { }
        }
        return 1.0f;
    }

    /** Display width (scaled resolution). */
    public static int getDisplayWidth() {
        Object mc = getMinecraft();
        if (mc == null) return 854;
        for (String f : new String[]{"field_71443_c", "displayWidth", "getWindowWidth", "method_1565", "c"}) {
            try {
                Object v = Reflection.getMember(mc, f);
                if (v instanceof Number) return ((Number) v).intValue();
            } catch (Throwable ignored) { }
        }
        return 854;
    }

    public static int getDisplayHeight() {
        Object mc = getMinecraft();
        if (mc == null) return 480;
        for (String f : new String[]{"field_71440_d", "displayHeight", "getWindowHeight", "method_1564", "d"}) {
            try {
                Object v = Reflection.getMember(mc, f);
                if (v instanceof Number) return ((Number) v).intValue();
            } catch (Throwable ignored) { }
        }
        return 480;
    }
}
