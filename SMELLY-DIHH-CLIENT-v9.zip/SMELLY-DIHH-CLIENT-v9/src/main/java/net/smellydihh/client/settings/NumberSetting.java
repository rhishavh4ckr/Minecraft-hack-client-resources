package net.smellydihh.client.settings;

/**
 * Double-backed numeric setting with min/max/step. Rendered as a slider
 * in the ClickGUI.
 */
public class NumberSetting extends Setting<Double> {
    private final double min, max, step;
    private final String unit;

    public NumberSetting(String name, String description, double defaultValue, double min, double max, double step, String unit) {
        super(name, description, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
        this.unit = unit;
    }

    public NumberSetting(String name, String description, double defaultValue, double min, double max, double step) {
        this(name, description, defaultValue, min, max, step, "");
    }

    public double getMin()  { return min; }
    public double getMax()  { return max; }
    public double getStep() { return step; }
    public String getUnit() { return unit; }

    public float getFloat() { return getValue().floatValue(); }
    public int   getInt()   { return getValue().intValue(); }

    @Override
    protected Double clamp(Double v) {
        if (v == null) v = getDefault();
        v = Math.max(min, Math.min(max, v));
        if (step > 0) v = Math.round(v / step) * step;
        return v;
    }
}
