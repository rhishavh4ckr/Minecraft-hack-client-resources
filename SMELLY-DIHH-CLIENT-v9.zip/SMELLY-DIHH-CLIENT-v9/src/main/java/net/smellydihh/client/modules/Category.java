package net.smellydihh.client.modules;

/**
 * Module categories matching the top-tab layout used in both VAPE v4 and the
 * LionClient ClickGUI. Order is preserved when rendering the tab bar.
 */
public enum Category {
    COMBAT   ("Combat",    0xFFFF5555),
    MOVEMENT ("Movement",  0xFF55FF55),
    PLAYER   ("Player",    0xFF5555FF),
    RENDER   ("Render",    0xFFFFAA00),
    WORLD    ("World",     0xFF55FFFF),
    MISC     ("Misc",      0xFFAA55FF),
    CLIENT   ("Client",    0xFF4AA0FF);

    private final String displayName;
    private final int accentColor;

    Category(String displayName, int accentColor) {
        this.displayName = displayName;
        this.accentColor = accentColor;
    }

    public String getDisplayName() { return displayName; }
    public int getAccentColor()  { return accentColor; }
}
