package net.smellydihh.client.modules.movement;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.NumberSetting;

public class Step extends Module {
    private final NumberSetting height = new NumberSetting("Height", "Step height in blocks.", 1.0, 0.5, 10.0, 0.5);
    public Step() { super("Step", "Walk up blocks like stairs.", Category.MOVEMENT, 0); addSetting(height); }
}
