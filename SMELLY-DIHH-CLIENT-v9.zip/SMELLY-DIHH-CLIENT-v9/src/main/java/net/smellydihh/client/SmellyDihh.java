package net.smellydihh.client;

/**
 * Global constants for SMELLY DIHH CLIENT.
 * Centralised so every subsystem pulls branding from one place.
 */
public final class SmellyDihh {

    /** Public display name – used in window titles, watermarks, chat, HUD. */
    public static final String NAME = "SMELLY DIHH CLIENT";

    /** Short lowercase version used for config folder names and package-safe ids. */
    public static final String ID = "smellydihh";

    /** Client version – bumped on each release. */
    public static final String VERSION = "1.0";

    /** Build type shown in HUD watermark. */
    public static final String BUILD = "release";

    /** Default keybind that opens the Click GUI (RIGHT_SHIFT = 54 on LWJGL). */
    public static final int CLICK_GUI_KEY = 54;

    /** Config directory name (inside the game .minecraft folder). */
    public static final String CONFIG_FOLDER = "SmellyDihhClient";

    private SmellyDihh() { /* utility */ }
}
