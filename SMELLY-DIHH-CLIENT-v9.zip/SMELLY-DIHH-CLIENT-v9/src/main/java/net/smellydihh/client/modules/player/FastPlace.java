package net.smellydihh.client.modules.player;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;

public class FastPlace extends Module {
    public FastPlace() { super("FastPlace", "Removes block-place delay.", Category.PLAYER, 0); }
}
