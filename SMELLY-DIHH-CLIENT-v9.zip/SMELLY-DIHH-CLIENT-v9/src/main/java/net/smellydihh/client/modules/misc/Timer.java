package net.smellydihh.client.modules.misc;

import net.smellydihh.client.modules.Category;
import net.smellydihh.client.modules.Module;
import net.smellydihh.client.settings.NumberSetting;

public class Timer extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", "Timer speed multiplier.", 1.0, 0.1, 10.0, 0.1);
    public Timer() { super("Timer", "Speeds up/slows down the game.", Category.MISC, 0); addSetting(speed); }
}
