package com.sun.jna;
import java.lang.reflect.Method;
public class Function { public static Function getFunction(String name){return new Function();} public Object invoke(Object[] args){return null;} public Object invoke(Object[] args, Class<?>[] t){return null;} }
