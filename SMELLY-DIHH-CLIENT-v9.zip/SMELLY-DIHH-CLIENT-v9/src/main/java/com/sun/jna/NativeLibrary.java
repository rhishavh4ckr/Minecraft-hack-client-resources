package com.sun.jna;
public class NativeLibrary { public static NativeLibrary getInstance(String n){return new NativeLibrary();} }
