package com.sun.jna;
public class Pointer { public Pointer(long p){} public Pointer(){} }
