package com.sun.jna;
public class Memory extends Pointer { public Memory(long s){super(s);} }
