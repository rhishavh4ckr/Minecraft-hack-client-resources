package cpw.mods.fml.common;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.TYPE) public @interface Mod { String modid() default ""; String value() default ""; String name() default ""; String version() default ""; }
