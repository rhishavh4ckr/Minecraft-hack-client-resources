@echo off
cd /d "%~dp0"
title SMELLY DIHH CLIENT
if not exist build\client-patched.jar (
    echo client-patched.jar not found - run build.bat first.
    pause
    exit /b 1
)
echo Launching SMELLY DIHH CLIENT injector...
start "" javaw -jar build\client-patched.jar
