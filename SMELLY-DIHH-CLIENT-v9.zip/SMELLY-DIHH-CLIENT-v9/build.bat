@echo off
REM =============================================================
REM  SMELLY DIHH CLIENT - clean build from source
REM =============================================================
setlocal
cd /d "%~dp0"
title SMELLY DIHH CLIENT - Building

echo.
echo  ==========================================
echo   SMELLY DIHH CLIENT - Building from source
echo  ==========================================
echo.

if exist build rmdir /s /q build
mkdir build\classes

echo [1/4] Scanning sources...
dir /s /b src\main\java\*.java > build\srclist.txt
for /f %%A in ('type build\srclist.txt ^| find /c /v ""') do set JAVACOUNT=%%A
echo       Found %JAVACOUNT% Java source files

echo [2/4] Copying resources...
xcopy src\main\resources\* build\classes\ /E /Y /Q >nul

echo [3/4] Compiling with javac...
javac -encoding UTF-8 -source 8 -target 8 -d build\classes -cp "src\main\java" @build\srclist.txt
if errorlevel 1 (
    echo.
    echo  *** COMPILE FAILED - see errors above ***
    echo.
    pause
    exit /b 1
)
echo       Compile OK.

echo [4/4] Packaging jar...
cd build\classes
set JAREXE=
if exist "%ProgramFiles%\Java\jdk-21.0.10\bin\jar.exe" set JAREXE=%ProgramFiles%\Java\jdk-21.0.10\bin\jar.exe
if "%JAREXE%"=="" if exist "%ProgramFiles%\Java\jdk-21\bin\jar.exe" set JAREXE=%ProgramFiles%\Java\jdk-21\bin\jar.exe
if not "%JAREXE%"=="" (
    "%JAREXE%" cfm ..\client-patched.jar META-INF\MANIFEST.MF .
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '*' -DestinationPath '..\client-patched.zip' -Force"
    move /y ..\client-patched.zip ..\client-patched.jar >nul
)
cd ..\..

echo.
echo  ==========================================
echo   BUILD OK
echo   Jar: %CD%\build\client-patched.jar
echo  ==========================================
echo.
echo  Double-click build\client-patched.jar to launch
echo  the injector, or run RUN.bat
echo.
pause
endlocal
