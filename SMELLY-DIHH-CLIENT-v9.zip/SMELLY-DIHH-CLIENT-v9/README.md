# 💩 SMELLY DIHH CLIENT 💩

A Minecraft cheat client written from scratch — inspired by VAPE v4's HUD and
LionClient's ClickGUI. Multi-loader (Forge, Fabric, LabyMod, external Java-Agent
injector) with a clean, maintainable codebase.

## Features
- VAPE v4-style HUD (top-left ArrayList, orange→red vertical accent rail, shadow text)
- LionClient-styled ClickGUI (navy `#1e2D3D` panels, `#4AA0FF` bright blue accent,
  top tab bar COMBAT/MOVEMENT/CLIENT/RENDER/PLAYER/MISC, confetti background,
  search bar, draggable/resizable layout)
- Stink-cloud green-graffiti splash screen ("SMELLY DIHH CLIENT")
- 21 modules across 6 categories
- Full setting system (boolean, slider, mode, color, keybind, groups)
- Dot-prefix commands (`.help`, `.toggle`, `.bind`, `.config`, `.theme`)
- JSON config autosave/autoload
- External Injector GUI (double-click the jar → opens a Swing window with an
  Inject button that attaches to a running Minecraft instance)

## Quick start
1. Install JDK 8 or newer (JDK 21 recommended — you already have this).
2. Double-click **`build.bat`** (or open CMD in this folder and run `build.bat`).
3. After it says BUILD OK, double-click `build\client-patched.jar` to launch the
   injector. Or run **`RUN.bat`**.
4. Launch Minecraft, then click **Inject** in the SMELLY DIHH CLIENT window.
5. In game, press **RIGHT_SHIFT** to open the ClickGUI.

## Default keybinds
| Key         | Action                |
|-------------|-----------------------|
| RIGHT_SHIFT | Open ClickGUI         |

Module keybinds can be changed via `.bind <module> <key>` (or in the GUI settings panel).

## Folder layout
```
src/main/java/...       All source code
src/main/resources/...  Fonts, splash, metadata, manifests
build.bat               Compiles and packages build\client-patched.jar
RUN.bat                 Launches the compiled injector jar
ARCHITECTURE.md         Full architecture report & design notes
```

See `ARCHITECTURE.md` for a complete breakdown of every subsystem, the reverse-
engineering notes from the reference client, and design decisions.

## Brand
Every visible string in the client says **SMELLY DIHH CLIENT** — package names,
window titles, HUD watermark, ClickGUI title, config folder (`~/.minecraft/SmellyDihhClient`),
jar metadata, splash screen, icon, and README. No "LionClient" references remain.
