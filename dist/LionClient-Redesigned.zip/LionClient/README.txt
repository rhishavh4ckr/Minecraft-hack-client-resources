LionClient Redesigned
=====================

1. Extract this zip.
2. Open a terminal inside the LionClient folder.
3. Run:
     mkdir build && cd build
     unzip ../LionClient-Redesigned.jar
     bash build-patched.sh
4. The runnable mod is at:  build/client-patched.jar
   Drop it in your mods folder or run "java -jar client-patched.jar".

Press RIGHT_SHIFT in-game to open the ClickGUI.
